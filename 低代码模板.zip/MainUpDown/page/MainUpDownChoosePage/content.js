
var baseUrl = "gengjs.MainUpDown.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function mainupdown_choose_list_grid_selection_getselectiontype() {
    return pageParam.single ? 'radio' : 'checkbox';
}

function confirm() {
    var selections = Gikam.getComp('mainupdown-choose-list-grid').getSelections();
    Gikam.getLastModal().close(selections);
}

function cancel() {
    Gikam.getLastModal().close();
}

function getGridRequestData() {
    return pageParam;
}

