
var baseUrl = "gengjs.MainUpDown.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();


function approve() {
    var grid = Gikam.getComp('mainupdown-audit-grid');

    Gikam.create('workflow').pass({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

function reject() {
    var grid = Gikam.getComp('mainupdown-audit-grid');

    Gikam.create('workflow').reject({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}


function getGridRequestData() {
    return pageParam;
}


