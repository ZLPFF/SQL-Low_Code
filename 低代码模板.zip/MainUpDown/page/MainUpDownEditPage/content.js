
var pageParam = CURRENT_WINDOW.getPageParam();
var baseUrl = "gengjs.MainUpDown.server.LcdpCoreUserService";


function insert() {
    Gikam.getComp('mainupdown-edit-grid').insert(baseUrl + '.insertData',[{}]);
}

function deleteRows() {
    Gikam.getComp('mainupdown-edit-grid').deleteRows(baseUrl + '.deleteData');
}

function getGridRequestData() {
    return pageParam;
}


function submit() {
    var grid = Gikam.getComp('mainupdown-edit-grid');

    Gikam.create('workflow').submit({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}




