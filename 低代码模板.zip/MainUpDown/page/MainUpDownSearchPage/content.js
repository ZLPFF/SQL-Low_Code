
var baseUrl = "gengjs.MainUpDown.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function getGridRequestData() {
    return pageParam;
}




