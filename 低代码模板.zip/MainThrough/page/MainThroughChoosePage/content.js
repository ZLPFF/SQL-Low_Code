
var baseUrl = "gengjs.MainThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();


function mainthrough_choose_list_grid_selection_getselectiontype() {
    return pageParam.single ? 'radio' : 'checkbox';
}

function confirm() {
    var selections = Gikam.getComp('mainthrough-choose-list-grid').getSelections();
    Gikam.getLastModal().close(selections);
}

function cancel() {
    Gikam.getLastModal().close();
}

function getGridRequestData() {
    return pageParam;
}

