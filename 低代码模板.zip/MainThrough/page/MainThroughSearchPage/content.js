
var baseUrl = "gengjs.MainThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function getGridRequestData() {
    return pageParam;
}
function loadDetailPage(field, row) {
    if (field === 'username') {
        workspace.window.loadPage('gengjs.MainThrough.page.MainThroughDetailPage', { id: row.id, sourcePage: 'search'});
    }


}

