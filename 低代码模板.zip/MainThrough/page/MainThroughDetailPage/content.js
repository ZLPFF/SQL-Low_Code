var pageParam = CURRENT_WINDOW.getPageParam();
var baseUrl = "gengjs.MainThrough.server.LcdpCoreUserService";


function back() {
   workspace.window.goBack();
}

function detailFormParam() {
    return {
        id: pageParam.id
    }
}




var pageConfigParam = {
    // 草稿状态详情页
    edit: {
        readonly: false,
        button: {
            'detail-button-approve': {
                hidden: true
            },
            'detail-button-reject': {
                hidden: true
            }
        }
    },
    // 审核中详情页
    audit: {
        readonly: true,
        button: {
            'detail-button-approve': {
                hidden: false
            },
            'detail-button-reject': {
                hidden: false
            }
        }
    },
    // 查询详情页
    search: {
        readonly: true,
        button: {
            'detail-button-submit': {
                hidden: true
            },
            'detail-button-approve': {
                hidden: true
            },
            'detail-button-reject': {
                hidden: true
            }
        }
    }
}

// 不同详情页页面配置
function onBeforePageConfigLoad() {
    var pageConfigId = 'edit'; // 默认页面配置id
    if (Gikam.isNotEmpty(pageParam) && Gikam.isNotEmpty(pageParam.sourcePage)) {
        pageConfigId = pageParam.sourcePage;
    }

    return pageConfigParam[pageConfigId];
}


function submit() {
    var form = Gikam.getComp('mainthrough-detail-base-info-form');
    Gikam.create('workflow').submit({
        data: [form.getData()],
        pageObject: pageObject
    }).done(function () {
        workspace.window.goBack();
    });
}

function approve() {
    var form = Gikam.getComp('mainthrough-detail-base-info-form');

    Gikam.create('workflow').pass({
        data: [form.getData()],
        pageObject: pageObject
    }).done(function () {
        workspace.window.goBack();
    });
}

function reject() {
    var form = Gikam.getComp('mainthrough-detail-base-info-form');

    Gikam.create('workflow').reject({
        data: [form.getData()],
        pageObject: pageObject
    }).done(function () {
        workspace.window.goBack();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}

