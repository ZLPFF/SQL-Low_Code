
var baseUrl = "gengjs.MainThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();
var detailPagePath = "gengjs.MainThrough.page.MainThroughDetailPage";
function getGridRequestData() {
    return pageParam;
}

function insert() {
    
    //来自右侧的预新增
    Gikam.preInsert({
        modalTitle: Gikam.propI18N('LCDP.MODULE.ADD'),
        page: 'gengjs.MainThrough.page.MainThroughDetailPage',
        formId: 'mainthrough-detail-base-info-form',
        fields: ['username'],
        url: baseUrl + '.insertData'
    }).done(function (id) {
        workspace.window.loadPage('gengjs.MainThrough.page.MainThroughDetailPage', {id : id});
    });
    
    
}

function deleteRows() {
    Gikam.getComp('mainthrough-edit-grid').deleteRows(baseUrl + '.deleteData');

}

function loadDetailPage(field, row) {
    if (field === 'username'){
        workspace.window.loadPage(detailPagePath, {id : row.id,sourcePage: 'edit'});
    }

}

function submit() {
    var grid = Gikam.getComp('mainthrough-edit-grid');

    Gikam.create('workflow').submit({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}

