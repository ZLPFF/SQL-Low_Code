# LCDP Workspace

- Session: `checked-out/gengjs/gengjs/MainThrough`
- Target Path: `gengjs.MainThrough.page.MainThroughSearchPage`
- Database: `MySQL`
- Sync Actor: `gengjs`
- Sync Policy: `published + checked-out/<actor>`
- Manifest: `manifest.json`
- Lookup: `lookup.json`
- Writeback: `java -cp "scripts;<driver-jar>" LcdpWorkspaceTool writeback <url> <username> <password> --manifest=manifest.json --driver=<jdbc-driver>`
