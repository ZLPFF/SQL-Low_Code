
var baseUrl = "gengjs.MainSubUpDown.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function mainsubupdown_choose_list_grid_selection_getselectiontype() {
    return pageParam.single ? 'radio' : 'checkbox';
}

function confirm() {
    var selections = Gikam.getComp('mainsubupdown-choose-list-grid').getSelections();
    Gikam.getLastModal().close(selections);
}

function cancel() {
    Gikam.getLastModal().close();
}

function getGridRequestData() {
    return pageParam;
}

