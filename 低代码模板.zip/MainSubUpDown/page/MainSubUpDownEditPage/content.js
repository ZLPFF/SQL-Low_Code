
var pageParam = CURRENT_WINDOW.getPageParam();
var baseUrl = "gengjs.MainSubUpDown.server.LcdpCoreUserService";

var baseLcdpCoreUserPermissionUrl = "gengjs.MainSubUpDown.server.LcdpCoreUserPermissionService";


function insert() {
    Gikam.getComp('mainsubupdown-edit-grid').insert(baseUrl + '.insertData',[{}]);
}

function deleteRows() {
    Gikam.getComp('mainsubupdown-edit-grid').deleteRows(baseUrl + '.deleteData');
}

function getGridRequestData() {
    return pageParam;
}


function submit() {
    var grid = Gikam.getComp('mainsubupdown-edit-grid');

    Gikam.create('workflow').submit({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}




function getCoreUserPermissionRequestData() {
    var grid =  Gikam.getComp('mainsubupdown-edit-grid');
    return {
        userid_SEQ: grid.getActivedRow().id
    }
}


function insertCoreUserPermission() {
    Gikam.getComp('mainsubupdown-edit-core-user-permission-grid').insert(baseLcdpCoreUserPermissionUrl+".insertData", [{
        userid: Gikam.getComp('mainsubupdown-edit-grid').getActivedRow().id
    }]);
}

function deleteCoreUserPermission() {
    Gikam.getComp('mainsubupdown-edit-core-user-permission-grid').deleteRows(baseLcdpCoreUserPermissionUrl+".deleteData");
}
