
var baseUrl = "gengjs.MainSubUpDown.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function getGridRequestData() {
    return pageParam;
}

function getCoreUserPermissionRequestData() {
    var grid =  Gikam.getComp('mainsubupdown-search-grid');
    return {
        userid_SEQ: grid.getActivedRow().id
    }
}




