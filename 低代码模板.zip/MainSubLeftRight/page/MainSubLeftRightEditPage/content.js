
var pageParam = CURRENT_WINDOW.getPageParam();
var baseUrl = "gengjs.MainSubLeftRight.server.LcdpCoreUserService";

var baseLcdpCoreUserPermissionUrl = "gengjs.MainSubLeftRight.server.LcdpCoreUserPermissionService";


function insert() {
    
    // 来自右侧的预新增
    Gikam.preInsert({
        modalTitle: Gikam.propI18N('LCDP.MODULE.ADD'),
        page: 'gengjs.MainSubLeftRight.page.MainSubLeftRightEditPage',
        formId: 'mainsubleftright-edit-base-info-form',
        fields: ['username'],
        url: baseUrl + '.insertData'
    }).done(function (id) {
        Gikam.getComp('mainsubleftright-edit-grid').refresh();
    });
    
    
}

function deleteRows() {
    Gikam.getComp('mainsubleftright-edit-grid').deleteRows(baseUrl + '.deleteData');
}

function getGridRequestData() {
    return pageParam;
}

function onUpdateFormData() {
    var grid = Gikam.getComp('mainsubleftright-edit-grid');
    grid && grid.refreshRowById(grid.getActivedRow().id);
}




function loadWfDetailPage(field, row) {
    if (field === 'wfnodename'){
        Gikam.create('WorkflowDesigner', {
            renderTo: workspace.window.$dom,
            procId: row.wfprocinstid,
            readonly: true
        });
    }
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}

function submit() {
    var grid = Gikam.getComp('mainsubleftright-edit-grid');

    Gikam.create('bizWorkflow').submit({
        data : grid.getSelections(),
        pageObject : pageObject
    }).done(function() {
        grid.refresh();
    });
}



function getCoreUserPermissionRequestData() {
    var grid =  Gikam.getComp('mainsubleftright-edit-grid');
    return {
        userid_SEQ: grid.getActivedRow().id
    }
}


function insertCoreUserPermission() {

    Gikam.getComp('mainsubleftright-edit-core-user-permission-grid').insert(baseLcdpCoreUserPermissionUrl+".insertData", [{
        userid: Gikam.getComp('mainsubleftright-edit-grid').getActivedRow().id
    }]);
}

function deleteCoreUserPermission() {

    Gikam.getComp('mainsubleftright-edit-core-user-permission-grid').deleteRows(baseLcdpCoreUserPermissionUrl+".deleteData");
}
