
var baseUrl = "gengjs.MainSubLeftRight.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();



function loadWfDetailPage(field, row) {
    if (field === 'wfnodename'){
        Gikam.create('WorkflowDesigner', {
            renderTo: workspace.window.$dom,
            procId: row.wfprocinstid,
            readonly: true
        });
    }
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}

function approve() {
    var grid = Gikam.getComp('mainsubleftright-audit-grid');

    Gikam.create('bizWorkflow').pass({
        data : grid.getSelections(),
        pageObject : pageObject
    }).done(function() {
        grid.refresh();
    });
}

function reject() {
    var grid = Gikam.getComp('mainsubleftright-audit-grid');

    Gikam.create('bizWorkflow').reject({
        data : grid.getSelections(),
        pageObject : pageObject
    }).done(function() {
        grid.refresh();
    });
}

function getGridRequestData() {
    return pageParam;
}

function getCoreUserPermissionRequestData() {
    var grid =  Gikam.getComp('mainsubleftright-audit-grid');
    return {
        userid_SEQ: grid.getActivedRow().id
    }
}


