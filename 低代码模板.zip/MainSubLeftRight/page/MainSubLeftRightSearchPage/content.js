
var baseUrl = "gengjs.MainSubLeftRight.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function getGridRequestData() {
    return pageParam;
}

function getCoreUserPermissionRequestData() {
    var grid =  Gikam.getComp('mainsubleftright-search-grid');
    return {
        userid_SEQ: grid.getActivedRow().id
    }
}



function loadWfDetailPage(field, row) {
    if (field === 'wfnodename'){
        Gikam.create('WorkflowDesigner', {
            renderTo: workspace.window.$dom,
            procId: row.wfprocinstid,
            readonly: true
        });
    }
}


