
var baseUrl = "gengjs.MainSubThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();


function mainsubthrough_choose_list_grid_selection_getselectiontype() {
    return pageParam.single ? 'radio' : 'checkbox';
}

function confirm() {
    var selections = Gikam.getComp('mainsubthrough-choose-list-grid').getSelections();
    Gikam.getLastModal().close(selections);
}

function cancel() {
    Gikam.getLastModal().close();
}

function getGridRequestData() {
    return pageParam;
}

