
var baseUrl = "gengjs.MainSubThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function loadDetailPage(field, row) {
    if ( field === 'username'){
        workspace.window.loadPage('gengjs.MainSubThrough.page.MainSubThroughDetailPage', {id : row.id,sourcePage: 'audit'});
    }

}

function getGridRequestData() {
    return pageParam;
}

function approve() {
    var grid = Gikam.getComp('mainsubthrough-audit-grid');

    Gikam.create('workflow').pass({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

function reject() {
    var grid = Gikam.getComp('mainsubthrough-audit-grid');

    Gikam.create('workflow').reject({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}

