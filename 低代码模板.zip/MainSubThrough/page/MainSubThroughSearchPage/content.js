
var baseUrl = "gengjs.MainSubThrough.server.LcdpCoreUserService";
var pageParam = CURRENT_WINDOW.getPageParam();

function getGridRequestData() {
    return pageParam;
}
function loadDetailPage(field, row) {
    if (field === 'username') {
        workspace.window.loadPage('gengjs.MainSubThrough.page.MainSubThroughDetailPage', { id: row.id, sourcePage: 'search'});
    }


}

