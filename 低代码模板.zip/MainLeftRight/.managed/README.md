# LCDP Workspace

- Session: `checked-out/gengjs/gengjs/MainLeftRight`
- Target Path: `gengjs.MainLeftRight.page.MainLeftRightSearchPage`
- Database: `MySQL`
- Sync Actor: `gengjs`
- Sync Policy: `published + checked-out/<actor>`
- Manifest: `manifest.json`
- Lookup: `lookup.json`
- Writeback: `java -cp "scripts;<driver-jar>" LcdpWorkspaceTool writeback <url> <username> <password> --manifest=manifest.json --driver=<jdbc-driver>`
