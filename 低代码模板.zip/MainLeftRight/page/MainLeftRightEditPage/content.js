
var pageParam = CURRENT_WINDOW.getPageParam();
var baseUrl = "gengjs.MainLeftRight.server.LcdpCoreUserService";


function insert() {
    
    // 来自右侧的预新增
    Gikam.preInsert({
        modalTitle: Gikam.propI18N('LCDP.MODULE.ADD'),
        page: 'gengjs.MainLeftRight.page.MainLeftRightEditPage',
        formId: 'mainleftright-edit-base-info-form',
        fields: ['username'],
        url: baseUrl + '.insertData'
    }).done(function (id) {
        Gikam.getComp('mainleftright-edit-grid').refresh();
    });
    
    
}

function deleteRows() {
    Gikam.getComp('mainleftright-edit-grid').deleteRows(baseUrl + '.deleteData');
}

function getGridRequestData() {
    return pageParam;
}

function onUpdateFormData() {
    var grid = Gikam.getComp('mainleftright-edit-grid');
    grid && grid.refreshRowById(grid.getActivedRow().id);
}


function submit() {
    var grid = Gikam.getComp('mainleftright-edit-grid');

    Gikam.create('workflow').submit({
        data: grid.getSelections(),
        pageObject: pageObject
    }).done(function () {
        grid.refresh();
    });
}

var pageObject = {
    baseUrl: baseUrl,
    workflow: {
        dbTable: 'T_CORE_USER'
    }
}





