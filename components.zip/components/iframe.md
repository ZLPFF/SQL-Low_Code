---
sidebarDepth: 1
---

# Iframe 框架<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#iframe-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件ID



### height
- 类型：`string`
- 默认值：`'100%'`

高度



### hidden
- 类型：`boolean`
- 默认值：`false`

初始化时是否隐藏

 ```javascript
 // 初始化隐藏之后可通过show方法，在合适的时机将其显示
 Gikam.getComp('id').show();
 ```


### renderTo
- 类型：`HtmlElement`
- 默认值：`null`

渲染到的DOM元素



### minHeight
- 类型：`string`
- 默认值：`'100px'`

最小高度



### scrolling
- 类型：`string`
- 默认值：`'no'`

是否显示滚动条



### getSrc

低代码动态获取src


