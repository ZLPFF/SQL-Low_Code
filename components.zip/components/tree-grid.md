---
sidebarDepth: 1
---

# TreeGrid 树表格<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#tree-grid-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### checkbox

是否显示节点复选框



### single

是否单选



### cascadeCheck
- 类型：`boolean`
- 默认值：`true`

勾选节点时，父节点和子节点是否同步勾选



### cascadeChildrenCheck
- 类型：`boolean`
- 默认值：`true`

勾选节点时，子节点是否同步勾选



### cascadeParentCheck
- 类型：`boolean`
- 默认值：`true`

勾选节点时，父节点是否同步勾选



### storeExpandedId
- 类型：`boolean`
- 默认值：`false`

数据刷新时，是否记录之前展开的节点



### defaultExpandAll
- 类型：`boolean`
- 默认值：`true`

默认是否展开全部展开节点



### defaultExpandedIds
- 类型：`string[]`
- 默认值：`[]`

默认展开的节点



### defaultSelectedIds
- 类型：`string[]`
- 默认值：`[]`

默认选中的节点



### checkNodeOnActive
- 类型：`boolean`
- 默认值：`false`

点击节点时，是否级联勾选复选框



### onNodeSelected
- 类型：`()=>void`
- 默认值：`null`

节点选中事件



### onToggleExpandState
- 类型：`(row,`
- 默认值：`expand)=>void`

树字段点击展开收缩图标时触发的事件


## 方法

### getCheckedNode()

获取选中的节点,如果节点中有半选状态，则为不选中


### changeChildren(nodeId, expand)
 - 参数：{ String }
 - 参数：{ boolean }

通过id展开或折叠节点


### getSelectedNode()
 - 返回值：object

获取选中的节点,如果节点中有半选状态，则为选中


### getSelections()
 - 返回值：object[]

获取选中数据


### changeAllNodes(expand)
 - 参数：{ boolean }

通过id展开或关闭子节点


### unCheckAllNodes()
 - 参数：{boolean} [options={ triggerEvent:

取消勾选所有节点


### moveUp(url)
 - 参数：{string} url 上移接口
 - 返回值：{Deferred}

将选中数据上移


### moveDown(url)
 - 参数：{string} url 下移接口
 - 返回值：{Deferred}

将选中数据下移


