---
sidebarDepth: 1
---

# confirm<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#confirm-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### message
- 类型：`string`
- 默认值：`null`

确认弹框内容



### title
- 类型：`string`
- 默认值：`请确认`

确认弹框标题



### subTitle
- 类型：`string`
- 默认值：`null`

确认弹框副标题



### noText
- 类型：`string`
- 默认值：`取消`

确认弹框取消按钮文本



### yesText
- 类型：`string`
- 默认值：`确定`

确认弹框确认按钮文本



### height
- 类型：`number`
- 默认值：`205`

确认弹框高度



### onNoClick
- 类型：`Function`
- 默认值：`null`

确认弹框取消按钮点击事件



### onYesClick
- 类型：`Function`
- 默认值：`null`

确认弹框确认按钮点击事件



### rootClass
- 类型：`string`
- 默认值：`null`

自定义样式的class名称



### onCloseClick
- 类型：`Function`
- 默认值：`null`

确认弹框关闭按钮点击事件


