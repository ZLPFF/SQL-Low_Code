---
sidebarDepth: 1
---

# BusinessProcessDiagram 业务流程图<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#businessProcessDiagram-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### url
- 类型：`string`
- 默认值：`null`

请求地址，请求方式为post，返回格式与data属性格式相同



### data
- 类型：`Array`
- 默认值：`[]`

展示数据，在不配置url时使用

```javascript
 // 具体格式如下
 [
    {
        // 取值范围: 'ended'| 'working'
        status: 'ended',
        // 名称
        masterConfName: '流程一',
        // 子流程
        subConfList: [
            {
                subConfName: '子流程一',
                donePercent: '100%',
                undonePercent: '0%',
            },
        ],
    },
    {
        status: 'working',
        masterConfName: '流程二',
        subConfList: [
            {
                subConfName: '子流程一',
                doneCounts: '10',
                allCounts: '100',
            },
        ],
     },
 ]
```
 效果如下：
 ![流程图](/docs/business-process-diagram.png)


### bizId
- 类型：`string`
- 默认值：`null`

业务ID，接口请求时，作为参数传入


## 方法

### refresh(param)
 - 参数：{object} options

刷新组件


