---
sidebarDepth: 1
---

# Carousel 轮播图<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#carousel-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件ID



### src
- 类型：`string[]`
- 默认值：`[]`

轮播项，图片地址



### noPictureText
- 类型：`null`

无图片可供预览时的自定义提示文字（会覆盖默认提示）string



### style
- 类型：`object`
- 默认值：`null`

自定义样式(包含可选width|height的样式属性)

 ```javascript
 {
     width: '100%',
     height: '300px'
 }
 ```


### arrows
- 类型：`boolean`
- 默认值：`false`

是否显示切换箭头



### autoplay
- 类型：`boolean`
- 默认值：`true`

是否自动切换



### interval
- 类型：`number`
- 默认值：`2000`

自动播放之间的间隔时长(单位：ms说明：若interval小于等于animationSpeed，则采用animationSpeed)



### dotPosition
- 类型：`string`
- 默认值：`bottom`

面板指示点位置(可选top|bottom|left|right)



### animationSpeed
- 类型：`number`
- 默认值：`800`

每次切换动画持续时长(单位：ms)



### dots
- 类型：`boolean`
- 默认值：`true`

是否显示面板指示点



### onAfterChange
- 类型：`(current:number)=>void`
- 默认值：`null`

切换面板后的回调

 ```javascript
 onAfterChange:function(current) {
     console.log(current);
 }
 ```


### onBeforeChange
- 类型：`(from:number,to:number)=>void`
- 默认值：`null`

切换面板前的回调

 ```javascript
 onBeforeChange:function(from, to) {
     console.log(from, to);
 }
 ```


### onRendered
- 类型：`()=>void`
- 默认值：`null`

组件渲染成功之后


## 方法

### goTo(index)
 - 参数：{number} index 索引

切换到指定索引面板


### next()

切换到下一个面板


### prev()

切换到上一面板


### setOptions(options)
 - 参数：{object} options

动态修改options参数


### getOptions()
 - 返回值：{object}

获取配置参数


