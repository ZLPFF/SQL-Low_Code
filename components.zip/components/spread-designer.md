---
sidebarDepth: 1
---

# spread-designer<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#spread-designer-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 

