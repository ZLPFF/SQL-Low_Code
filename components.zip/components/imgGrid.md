---
sidebarDepth: 1
---

# ImgGrid 图片列表组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#imgGrid-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件id，跟随业务命名



### url
- 类型：`string`
- 默认值：`null`

请求数据接口地址



### drag
- 类型：`boolean`
- 默认值：`false`

图片是否支持拖动排序



### requestData
- 类型：`object`
- 默认值：`null`

请求数据接口使用的数据



### data
- 类型：`Array`
- 默认值：`[]`

图片列表数据

 ```javascript
 data: [{
    id: '文件的数据id',
    name: '文件名称',
    downloadUrl:'文件的下载地址'
    previewUrl :'预览大图的文件地址，如果没有则预览downloadUrl'
 }]
 ```


### hiddenBtn
- 类型：`Array`
- 默认值：`[]`

隐藏头部按钮，元素为Boolean类型，两个元素，对应删除和刷新按钮

 ```javascript
 // 隐藏删除按钮写法
   hiddenBtn: [true, false]
 ```


### width
- 类型：`number`

展示区域的宽度



### height
- 类型：`number`

展示区域的高度



### onClick

单击图片触发的操作，单击激活选中图片



### onDblclick

双击击图片触发的操作，双击可查看放大后的图片



### onDrag

排序事件



### onRendered

组件渲染完成事件



### onDelete

点击删除按钮



### page

分页



### viewType
- 类型：`两个属性:normal和viewer`

预览图片模式:



### row

//行



### column

//列



### checked

//是否显示多选框



### showImgName

是否展示图片名称



### checkbox
- 类型：`Boolean`
- 默认值：`true`

多选模式



### formatterButtons

动态设置按钮

 ```javascript
 formatterButtons(items) {
    return [{
     text: '新增',
     icon: 'add',
    }].concat(items);
 },
 ```


### onModifyClick
- 类型：`Function`
- 默认值：`null`

预览图片弹框中点击替换按钮触发的操作


## 方法

### setData(data)
 - 参数：{ Array }

动态填充数据


### getSelections()

返回选中图片


### getData()

获取所有图片


### setOptions(option)
 - 参数：{ Object }

动态设置属性对象


### refresh(param)
 - 参数：{ Object }

刷新组件


### getUrlData()

从url获取数据


## 应用

### 图片表格示例代码:

```javascript
{
    type: 'imgGrid',
    id: 'core-imgGrid',
    url: IFM_CONTEXT + '/core/module/item/files/queries',
    requestData: {
        targetId: 'T_CORE_NOTICE$927365792095040'
    },
    onDelete: function(selection, node) {
        Gikam.alert('删除方法业务上实现');
    }
}
```
列表效果如下：
![imgGrid](/docs/imgGrid-01.png)
双击图片效果如下：
![imgGrid](/docs/imgGrid-02.png)
