---
sidebarDepth: 1
---

# ButtonToolbar 按钮工具栏<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#button-toolbar-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### items
- 类型：`object[]`
- 默认值：`null`

按钮选项，类型包含button和Dropdownmenu



### align
- 类型：`'left'|'center'|'right'`
- 默认值：`'left'`

对齐方式


