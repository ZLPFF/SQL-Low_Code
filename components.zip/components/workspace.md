---
sidebarDepth: 1
---

# Workspace 工作台<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#workspace-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性

### style

页面风格

### compactStyle

紧密类型

### logo

- 类型：`string`
- 默认值：`null`

系统LOGO图片地址

### fullScreenLogo

- 类型：`string`
- 默认值：`null`

菜单收缩之后显示的Logo

### skin

- 类型：`#055F96`

皮肤主题，16进制色系

### switchDeptAndRole

- 类型：`boolean`
- 默认值：`false`

是否切换部门和角色

### switchDept

- 类型：`boolean`
- 默认值：`false`

是否切换部门

### switchRole

- 类型：`boolean`
- 默认值：`false`

切换角色

### switchTenant

- 类型：`boolean`
- 默认值：`false`

//是否切换租户

### canModifyPwd

- 类型：`boolean`
- 默认值：`true`

更改密码

### menuList

菜单

### simpleMenuList

快捷菜单

### miniMenuSroll

- 类型：`boolean`
- 默认值：`false`

收起菜单后菜单是否滚动展示

### title

- 类型：`string`
- 默认值：`null`

系统名称

### xIconUrl

- 类型：`string`
- 默认值：`null`

配置系统小图标

### appendUserSettingPanelItems

- 类型：`function`
- 默认值：`function(){}`

在用户设置面板中增加按钮

```javascript
 // 如下示例，增加测试按钮
 appendUserSettingPanelItems: function() {
     return [{
         text : '测试',
         onClick : function() {
             alert("点击事件");
         }
     }]
 }
```

### activeMenuId

- 类型：`string`
- 默认值：`null`

登陆成功进入系统后需要激活的菜单，一般在单点登陆时使用

### navIcons

- 类型：`Array`
- 默认值：`['platform']`

配置导航图标

```javascript
 // 映射关系
 {
      platform : '待办',
      specialCharacter : '特殊字符',
      helpManual : '帮助手册，后台返沪帮助手册，不需要配置',
      notification : '消息通知，系统配置菜单选择，不需要配置',
      enterFullScreen : '全屏, 属性showFullScreen',
      layoutEditShow : '手机端拖拽布局，移动端才会显示，不需要配置',
      dataCenterReport : '大屏展示，属性dataCenterReport.show'
  }
```

### navIconFormatter

- 类型：`()=>{template:string}`
- 默认值：`null`

自定义导航图标

```javascript
 navIconFormatter : function(icons) {
     return icons.concat([{
         template : '<img src="/static/test.png" onclick="imgClickHandle()"/>'
     }])
 }
```

### enableLogout

- 类型：`boolean`
- 默认值：`true`

是否禁用用户退出登录功能

### showFullScreen

- 类型：`boolean`
- 默认值：`false`

是否显示全屏预览按钮

### mobileDisplayMode

- 类型：`'pc'|'mobile'`
- 默认值：`'pc'`

页面显示模式

### sessionTimeout

- 类型：`Function`
- 默认值：`null`

登陆超时自定义方法，一般用于重写系统超时逻辑

### helpManualUrl

帮助文档路径

### todoVoicePrompt

待办是否声音提醒

### rollingNotice

- 类型：`boolean`
- 默认值：`false`

是否展示滚动公告

### rollingNoticeClick

- 类型：`Function`

滚动公告点击事件，配置了此事件，底层的点击事件就不生效了

### onTodoItemClick

- 类型：`Function`
- 默认值：`null`

待办点击

### notificationIds

消息通知数据id

### confirmClose

- 类型：`boolean`
- 默认值：`false`

在浏览器关闭系统时，是否提示“系统可能不会保存您所做的更改，是否继续”,

### customPanelUrl

- 类型：`string`
- 默认值：`null`

自定义首页面板路径，会替换现有的首页展示方案

### logout

- 类型：`Function`
- 默认值：`null`

自定义注销方法

### customAvatar

- 类型：`(url)=>string`
- 默认值：`null`

更改系统默认的头像，在方法中返回图片地址

### indexPanelConfig

- 类型：`boolean`
- 默认值：`true`

用户头像下拉菜单中是是否显示首页配置

### sideAutoToggle

- 类型：`boolean`
- 默认值：`true`

左侧菜单是否根据浏览器宽度自动收缩，例如在平板中进入系统后左侧菜单会自动收缩

### voiceSingleNum

- 类型：`boolean`
- 默认值：`false`

语音播报时，对于数字是否按单个字符读取，默认会按照数字的单位进行读取

### expandFirstSubMenu

- 类型：`boolean`
- 默认值：`false`

是否展开二级菜单的第一个菜单,适用于海棠风格

### showAdminManager

- 类型：`“切换至后台管理”`
- 默认值：`boolean`

是否展示头像下拉框下面的

### sideBar

- 类型：`object`
- 默认值：`{defaultWidth:200,manualStretch:false,autoShrink:true,begoniaAutoShrink:false}`

菜单栏配置

```javascript
{
    // 菜单栏默认宽度200，最大400，最小200
    defaultWidth: 200,
    // 菜单栏是否可以手动拖拽
    manualStretch: false,
    // 菜单是否自动收缩
    autoShrink: true,
    // begonia皮肤激活菜单，左侧二级菜单组是否自动收缩
    begoniaAutoShrink: false,
    // begonia皮肤左侧所有菜单是否默认展开
    begoniaDefaultExpand: false,
    // begonia皮肤切换至首页后，左侧二级菜单是否自动收缩
    begoniaShrinkOnHome: true,
    // 春兰皮肤快捷菜单是否支持固定
    simpleMenuCanFixed: false,
    // 玉兰皮肤搜索框位置 left top
    searchInputPosition: 'top',
    // 在菜单区域鼠标右击时，下拉菜单选项，配置格式contextMenu: [{text:'按钮名称',onClick:function(node){alert('复制链接');}}]
    contextMenu: [],
    // 显示菜单刷新按钮 boolean true
    refresh: true,
    // 玉兰皮肤菜单是否默认打开 boolean false
    defaultExpand: false,
}
```

### dataCenterReport

- 类型：`object`
- 默认值：`{show:false,defaultOpen:false,lazyLoad:`

数据大屏配置

```javascript
{
    // 是否显示展示数据中心大屏
    show: false,
    // 进入系统后是否默认打开大屏展示窗口
    defaultOpen: false,
    // 是否懒加载,设置为true的话则首次打开时只会渲染一个大屏
    lazyLoad: false,
    // 请求大屏数据的接口参数 object {}
    param: {},
}
```

### enableAgent

- 类型：`boolean`
- 默认值：`false`

是否开启代理功能

### enableInstantMessage

- 类型：`boolean`
- 默认值：`false`

是否启用即时聊天功能

### enableAgentVoicePrompt

- 类型：`boolean`
- 默认值：`false`

是否开启聊天声音提示

### showTimeLine

是否显示即时聊天时间轴

### chatParam

即时聊天参数

```javascript
{
    // 消息对应业务数据字段名 string ''
    messageBizField: '',
    // 是否启用@热键选择数据 boolean false
    enableAtSelect: false,
    // 是否可快速回复 boolean false
    quickReply: false,
    // 热键@事件 (callback)=>void null
    onKeyDownAt: null,
    // 发送消息之前的事件,返回true则继续发送消息，返回false不发送 (message)=>boolean null
    onBeforeSendMessage: null,
    // 发送消息之后的事件 (message)=>void null
    onAfterSendMessage: null,
    // 回执图标点击事件，返回内容填入聊天的输入框中  (message)=>{return backMessage} null
    onQuickReplyClick: null,
    // 点击头像是否缩小聊天面板 boolean false
    collapseOnAvatarClick: false,
    // 消息抖动效果 boolean false
    messageShake: false,
}
```

### indexPanelHeightAuto

- 类型：`boolean`
- 默认值：`false`

首页面板高度是否根据浏览器高度自适应

 :::tip 提示
 自适应时，面板每等分高度为浏览器窗口高度的1/3，
 非自适应时，面板每等分高度为140px
 :::

### indexPanelRowHeight

首页面板每等分高度

### miniMenuPageSize

- 类型：`Number`
- 默认值：`8`

菜单收缩时，简便图标每页展示菜单个数

### rememberLastActiveMenu

- 类型：`boolean`
- 默认值：`false`

是否记录上一次激活的菜单,如果设置为true,浏览器刷新后会打开之前的菜单

### canSwitchLanguage

- 类型：`boolean`
- 默认值：`false`

是否可以切换系统语言

### enableAvatarModify

- 类型：`boolean`
- 默认值：`true`

用户设置面板中显示修改头像属性

### notificationAudio

页面提示音

### showReopen

- 类型：`boolean`
- 默认值：`false`

菜单页签右键菜单是否显示“重新打开”

### todoDisplayCategory

- 类型：`'common|group'`
- 默认值：`'common',`

待办显示方式

### getSimpleMenu

是否请求快捷菜单

### customNotification

右下角消息通知属性

```javascript
{
    // 自动关闭时间，默认不自动关闭，单位s number 0
    duration: 0,
    // 自动关闭之后是否调用查看接口 Boolean false
    autoCloseRead: false,
    // 点击查看详情按钮跳转使用，前端设置全部消息通知都生效
    pageActiveForce: false,
    // 是否创建右下角弹框 默认为true-可弹出来
    enabled: true,
}
```

### homeTitle

- 类型：`string`
- 默认值：`''`

首页标签名称,项目上可自定义标题

### onAfterPageClose

- 类型：`(id:string,text:string)=>void`
- 默认值：`null`

业务页面关闭之后

### onBeforePageClose

- 类型：`(id:string,text:string)=>void`
- 默认值：`null`

页面关闭之前

### onTimeoutLogin

- 类型：`Function`
- 默认值：`null`

自定制超时登陆弹窗中登陆按钮逻辑

### onForcedOffline

- 类型：`Function`
- 默认值：`null`

强制下线自制跳转逻辑

### onEncryptPassword

- 类型：`(password,rsaPublicKey)=>password`
- 默认值：`null`

登录请求发送之前,加密密码时触发,可业务上返回其他算法加密后的密码

### loginExceptionMessage

自定义强制用户下线时的提醒

### homeShowComp

- 类型：`tenant-home-page`

首页面板组件

### grayMode

- 类型：`string`
- 默认值：`'0'`

系统灰色模式

### timeoutLoginTitle

- 类型：`string`
- 默认值：`null`

超时重新登录弹框标题

### isActiveNodeTabDrag

- 类型：`boolean`
- 默认值：`true`

打开的页签是否支持拖拽改变顺序

### zoom

- 类型：`number`
- 默认值：`null`

缩放比例

### indexPanelConfigReset

- 类型：`Function`
- 默认值：`null`

首页面板配置中恢复默认按钮逻辑

### allowOpenedPageNum

- 类型：`number`
- 默认值：`-1`

菜单页签允许打开的页面数量

### onMenuLoadSuccess

- 类型：`Function`
- 默认值：`null`

菜单加载成功事件

## 方法

### activeNodeById(id, param, force = false)

- 参数：{string|number} id
- 参数：{object} param 传递到页面的参数
- 参数：{boolean=false} force 页面是否关闭再重新打开，当传递的页面参数改变时，可开启此属性

通过菜单id激活菜单并进入页面

 ```javascript
 // 激活菜单，并向页面传入参数
 workspace.activeNodeById("001", {userName:'test',userCode: 222})
 ```

### closeCurrentPage()

关闭当前页面

### hideIndexPanelConfig()

隐藏首页面板

### openPage(param = {})

- 参数：{url:string,title:string} [param={}]

通过URL打开没有对应菜单的页面

### closePageById(id)

- 参数：String id

通过菜单id关闭菜单

### upDateTodoList(todoList)

手动更改待办事项

### closeAllPage()

关闭所有页面
