---
sidebarDepth: 1
---

# audio<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#audio-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### src
- 类型：`string`
- 默认值：`null`

音频地址，不配置用系统自带的音频文件



### type
- 类型：`normal|danger|warning|success|info`
- 默认值：`normal`

音频类型


