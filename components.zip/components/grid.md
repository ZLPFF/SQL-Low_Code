---
sidebarDepth: 1
---

# Grid 表格<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#grid-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件ID



### columns
- 类型：`string[]`
- 默认值：`[]`

表格显示的列

 ```javascript
 {
     columns : [ {
         checkbox : true
     }, {
        index : true
     }, {
        field : 'id',
        title : 'T_CORE_USER.ID',
        type : 'link',
        genericQuery : true,
        width: 100
     }, {
        field : 'userNo',
        title : 'T_CORE_USER.USERNO',
        genericQuery : true,
        width: 150,
        editor: true
     },
 }
 ```


### url
- 类型：`string`
- 默认值：`null`

定义表格数据来源的接口地址，接口使用post请求，返回分页格式数据



### customSearchData
- 类型：`object`
- 默认值：`null`

每次查询时，传入到接口中的过滤参数，与requestData请求参数合并



### customContent
- 类型：`string`
- 默认值：`null`

定义表格体中显示的内容



### toolbar
- 类型：`[]`

定义工具栏内容，其子组件可为form，button

 ```javascript
 // 新增按钮
 toolbar : [{
    type : 'button',
    text : 'GIKAM.BUTTON.INSERT',
    icon : 'add',
    onClick : function() {}
 }]

 // 新增查询条件
 toolbar : [{
     type : 'form',
     fields : [
        {
            type: 'text',
            field: 'name'
        }
     ]
 }]
 ```


### toolbarAlign
- 类型：`'right'|'left'`
- 默认值：`'right'`

工具栏中按钮的对齐方式



### columnResize
- 类型：`boolean`
- 默认值：`true`

是否可拖拽列宽度



### requestData
- 类型：`object`
- 默认值：`{}`

请求参数



### order
- 类型：`object|boolean`
- 默认值：`{}|true`

排序字段，例如name字段降序：{name:&nbsp;'desc'}，配置为false时，可以阻止表头字段点击排序



### sort
- 类型：`boolean`
- 默认值：`true`

排序字段，配置为false时，可以阻止表头字段点击排序



### page
- 类型：`boolean`
- 默认值：`true`

是否显示分页，没有分页时，表格会请求所有数据



### pageNum

当前第几页



### pageSize
- 类型：`number`
- 默认值：`50`

每页显示的数量



### data
- 类型：`object[]`
- 默认值：`[]`

如果没有配置url，初始化时可配置数据



### height
- 类型：`number|'auto'`
- 默认值：`400`

表格高度，若取值'auto',根据内容自适应。

 ::: tip 提示
 在Layout布局中，若某个区域内只有一个Grid组件，该Grid高度默认为所在区域的高度
 :::


### showBody
- 类型：`boolean`
- 默认值：`true`

是否显示表格



### autoSave
- 类型：`boolean`
- 默认值：`true`

是否开启自动保存，开启后编辑器值发生变化即调用接口进行保存



### pageList
- 类型：`Array`
- 默认值：`[50,`

分页器中，可选择的每页显示记录的数量



### deleteFormatter
- 类型：`Function`
- 默认值：`默认提示每条记录的id`

调用deleteRows方法删除数据时，确认框提示的内容

 ```javascript
 deleteFormatter: function(row) {
     return row.name;
 }
 ```


### activateFormatter
- 类型：`Function`
- 默认值：`默认提示每条记录的id`

调用activateRows方法启用数据时，提示内容对应的格式化方法，相关写法参照deleteFormatter



### suspendFormatter
- 类型：`Function`
- 默认值：`默认提示每条记录的id`

调用suspendRows方法删除数据时，提示内容对应的格式化方法，相关写法参照deleteFormatter



### checkOnActive
- 类型：`boolean`
- 默认值：`true`

激活行时是否勾选复选框



### initTriggerChange
- 类型：`boolean`
- 默认值：`true`

初始化时是否激活字段的change事件



### checkOneOnActive
- 类型：`boolean`
- 默认值：`false`

当前行激活且选中当前行复选框时，是否取消其他行选中

 :::tip 提示
 如果设置`checkOnActive`为`false`时，该功能没有效果。
 同时设置`checkOnActive`为`true`，`checkOneOnActive`为`true`时，开启此功能
 :::


### group
- 类型：`object`
- 默认值：`{}`

行分组功能，需要后台根据分组字段进行排序
```javascript
{
    // 是否显示行分组选中功能
    groupCheckbox: true,
    // 根据数组中哪些字段进行分组，相同的值会被归为一组
    fields: [],
    // 分组行显示的内容，例如 formatter(row){ return "<div>" + row.name + "</div>" }
    formatter: null,
    // 分组节点是否默认展开
    expand: true,
    // 每个分组的`序号`列是否单独显示索引
    groupIndex: false,
    // 统计哪种类型的复选框数量'normal'|'group'
    checkBadgeMode: 'normal',
    // 分组字段强制排序
    sortEnable: true,
    // 刷新后保持分组状态
    recordStatus: false,
    // 分组字段排序规则 'asc'|'desc'
    sortDirection: 'asc',
}
```



### filterOpen
- 类型：`boolean`
- 默认值：`false`

快捷查询是否默认展开



### filter
- 类型：`boolean`
- 默认值：`true`

是否开启快捷查询功能，该功能关闭后，用户无法使用表头查询功能



### generalButtonGroup
- 类型：`string[]`
- 默认值：`[]`

自定义通用按钮组，空数组时显示`刷新`、`导出`功能

 ```javascript
 // 只显示刷新按钮的配置
 generalButtonGroup: ['refresh', 'import', 'export', 'config']
 ```


### generalButtonGroupShow
- 类型：`boolean`
- 默认值：`true`

是否显示表格右上方通用按钮



### generalPanelTrigger
- 类型：`|`
- 默认值：`['click']`

通用按钮展开方式，悬浮和点击两种方式，空数组时两种都支持，['hover']



### editorInvisible
- 类型：`boolean`
- 默认值：`false`

单元格编辑器默认是否可见，为true时，不可见，即编辑器对应的表头颜色为蓝色，单击单元格才可对其进行编辑



### textLineFeed
- 类型：`boolean`
- 默认值：`false`

单元格文本内容超过列宽时，文本是否换行



### showCheckedNum
- 类型：`boolean`
- 默认值：`true`

选中复选框时，是否显示选中数量的角标，默认选中数量大于1时才会显示该角标



### columnsFill
- 类型：`boolean`
- 默认值：`true`

所有列总宽度小于表格容器的宽度时，是否充满整个表格区域。填充方式由columnAutoFill属性设置



### columnAutoFill
- 类型：`boolean`
- 默认值：`false`

设置为false,则最后一列为适配列，会自动填充空白区域;设置为true，若所有列都设置了宽度，则所有列按比例均分剩余空白区域宽度;若还有列未设置宽度，则剩余未设置宽度的列均分剩余空白区域宽度



### defaultColumnWidth
- 类型：`number`
- 默认值：`120`

不设置列宽时，默认的列宽



### contextmenu
- 类型：`boolean`
- 默认值：`[]`

在表格区域鼠标右击时，下拉菜单选项，如果不显示右上角常用按钮，则配置的下拉菜单会追加到常用菜单后面

 ```javascript
 contextmenu: [
     {
         text:'编辑',
         icon:'edit',
         type:'button',
         onClick:function(){
             alert('在下拉菜单中增加了编辑按钮');
         }
     }
 ]
 ```


### sum
- 类型：`object`
- 默认值：`{}`

在表格最后显示`合计`行
```javascript
{
    // 对哪些列进行数据合计，请求接口时，后台会进行运算，并返回totalMap字段
    fields: [],
    // 某些列需要统计总数量而非数值的累加，需要配置此属性，例如nonNumberFields: ['field1', 'field2']
    nonNumberFields: [],
    // `合计`二字从哪列开始显示，默认为0
    beginIndex: 0,
    // `合计`二字横跨到哪列，默认是1，即前两列会显示
    endIndex: 1,
    // 合计行是否冻结在表格末尾
    fixed: false,
}
```



### serverSearch
- 类型：`是否服务器端查询`

快捷查询时，



### contentAlign
- 类型：`'left'|'center'|'right'`
- 默认值：`'left';`

单元格内容对齐方式



### instantSavePath
- 类型：`string`
- 默认值：`null`

自动保存时的接口地址

 ::: tip 提示
 该属性一般不需要配置，只要按照规范开发接口，配置url后，后台会在数据查询后，
 将保存路径设置到`response`中，其key为`GIKAM-INSTANT-SAVE-PATH`，
 若此路径不能满足个别业务场景，需要设置此属性值
 :::


### activateFirstRow
- 类型：`boolean`
- 默认值：`false`

数据加载成功后是否激活第一行



### columnsSelect
- 类型：`boolean`
- 默认值：`false`

是否启用列选中，启用后，点击表头即可选中整列，通过`getActivedColumn`方法即可获取到整列参数



### hidden
- 类型：`boolean`
- 默认值：`false`

初始化时是否显示表格



### headRequestData
- 类型：`object`
- 默认值：`{}`

配置快捷查询条件，该条件值会显示在表头快捷查询的输入框、下拉框等组件中

 ```javascript
 headRequestData : {
     code : workspace.user.id,
     addData: '2022-01-01,2022-01-10'
 }
 ```


### activeOnCheck
- 类型：`boolean`
- 默认值：`false`

勾选复选框时是否激活行



### confirmField

删除、激活、注销等对列表的操作时，对哪个字段的值进行提示



### firstRowFixed
- 类型：`boolean`
- 默认值：`false`

首行是否冻结



### scroll
- 类型：`'visible'|'auto'|'native'`
- 默认值：`'auto'`

滚动条显示模式

 ```javascript
 visible：滚动条一直显示；
 auto: 鼠标悬浮于表格显示；
 native: 显示浏览器原生滚动条
 ```


### scrollButtonEnable
- 类型：`boolean`
- 默认值：`false`

滚动条是否显示滑动箭头



### useStorageColumns
- 类型：`boolean`
- 默认值：`true`

是否显示`列配置`或者`页面编辑`配置保存的列。true时，配置的列生效；false时js文件中的列生效



### toolbarHidden
- 类型：`boolean`
- 默认值：`false`

表格初始化时是否隐藏顶部工具栏



### name
- 类型：`string`
- 默认值：`null`

导出表格数据时，指定下载文件名称



### showPagination
- 类型：`boolean`

是否显示分页器



### filterImmediate
- 类型：`boolean`
- 默认值：`false`

快捷查询输入框在文本输入过程中，是否触发表格刷新，false时失去焦点时触发



### showSortArrow
- 类型：`boolean`
- 默认值：`false`

是否显示表格排序列箭头



### contextMenuConfig
- 类型：`boolean`
- 默认值：`false`

在表格内容区域点击鼠标右键，是否会弹窗显示下拉菜单



### checkedIds
- 类型：`(string|number)[]`
- 默认值：`[]`

数据加载后，默认勾选的行，值为id数组



### checkContinuous
- 类型：`boolean`
- 默认值：`false`

切换分页时，是否保留前一页选择的行数据



### dataLockWatch
- 类型：`boolean`
- 默认值：`false`

是否开启数据锁



### rootClass
- 类型：`string`
- 默认值：`null`

根元素class，用于项目自定义样式使用



### exportWithStyle
- 类型：`boolean`
- 默认值：`true`

导出Excel文件时,单元格样式是否按照字段方法`styleFormatter`的逻辑进行导出，其中行数据的命名必须用`row`

 ```javascript
 styleFormatter: function(row) {
    return {
         backgroundColor: row.name === 'test' ? 'red' : 'blue'
    }
 },
 ```


### advancedSearch
- 类型：`object`
- 默认值：`null`

高级查询配置
```javascript
{
    // 高级查询显示方式：popup：弹窗展示；top：表格上方展示;
    mode: 'top',
    defaultConfig: [],
    // 初始化时是否显示高级查询区域
    show: false,
    // 初始化时是否展开,仅mode为top时生效
    expand: true,
    // 高级查询最大高度,默认为300px
    maxHeight: 300,
    // 高级查询面板的标题,仅mode为top时生效
    title: '',
    // 高级查询面板的标题样式,仅mode为top时生效
    titleStyle: null,
}
```



### commonSearch

匹配所有列查询



### enableKeySwitchEditor
- 类型：`boolean`
- 默认值：`true`

是否开启方向键、Enter、Tab键切换单元格编辑器



### toggleCheckOnActive
- 类型：`boolean`
- 默认值：`true`

激活行时是否切换复选框选中状态。false时，激活行则级联勾选复选框，之后复选框不再随行激活状态进行切换，除非手动点击复选框取消勾选



### exportExcelHeader

导出时配置请求header里面的内容



### loadingMode
- 类型：`'normal'|'retro'|'progress'`
- 默认值：`'progress'`

数据加载过渡动画



### dataKeyFields
- 类型：`string[]`
- 默认值：`['id']`

指定数据中主键字段，可以配置多个字段即为联合主键



### onRowDblclick

行双击事件



### checkOnActiveGroupRow
- 类型：`boolean`
- 默认值：`false`

激活分组行时，是否勾选该分组行复选框



### appendButtonsToGeneral
- 类型：`object[]`
- 默认值：`[]`

向通用按钮组中追加按钮

 ```javascript
 appendButtonsToGeneral: [
    {
        type: 'button',
        text: '测试',
        onClick: function() {},
    },
 ],
 ```


### formatterParamOnExportExcel
- 类型：`(param:object)=>param`
- 默认值：`null`

导出Excel时追加额外的参数



### onBeforeExport
- 类型：`null`
- 默认值：`boolean|deffer`

导出excel之前的逻辑，如果返回值为false则不导出



### formatterKeyDirection
- 类型：`()=>&nbsp;object`
- 默认值：`null`

自定义按键切换编辑器方向

 ```javascript
 // 回车键向右切换编辑器
 formatterKeyDirection: function() {
     return {
         13: 'right',
     };
 },
 ```


### enableGetDataByUrl
- 类型：`boolean`
- 默认值：`true`

是否允许表格通过refresh方法刷新数据,若设置为false，调用refresh方法时，不再刷新



### showCheckedBadgeGt

选中角标超过指定数量时显示



### searchPanelEnabled

是否开启搜索面板



### searchPanelOptions

搜索面板表单配置



### exportHiddenColumns
- 类型：`boolean`
- 默认值：`true`

导出Excel文件时，是否导出隐藏列



### enterKeyDownActive
- 类型：`boolean`
- 默认值：`false`

按回车键时，是否激活行



### tabKeyDownActive
- 类型：`boolean`
- 默认值：`false`

按tab键时，是否激活行



### toolbarWrap
- 类型：`boolean`
- 默认值：`false`

在工具栏中，若按钮无法在一行全部显示，是否换行。设置为false，该行空间不足时，会将其折叠到`更多`下拉菜单按钮中



### pageBtnMode
- 类型：`'classic'|'simple'`
- 默认值：`'simple'`

分页器显示样式，'classic'模式下显示首页和末页按钮



### badgeOverflowCount
- 类型：`number`
- 默认值：`99`

角标最大显示数量，超过改数量则显示`+`



### rowTitleRender
- 类型：`(row)=>string`
- 默认值：`null`

鼠标悬浮到某行时的提示信息



### export
- 类型：`{url:string}`
- 默认值：`null`

导出Excel的配置参数，一般不需要配置。若通用导出接口无法满足需求，可自定制url
```javascript
{
    url: '',
    // 展示异步导出按钮
    asyncExportExcel: true,
    // 导出内容的值
    exportContent: '1',
    // 导出日志标识 默认值0 ，改为1时后台存在导出日志
    exportLog: '0',
    // 格式化导出的文件名称
    formatterFileName: null,
}
```



### readonlyErrorMessage
- 类型：`string`
- 默认值：`null`

只读字段自定义的错误校验信息，字段里的设置优先级高于grid



### onlyCurRowOrColMove

回车焦点只在当前行或列上移动



### notAllowToOriginal
- 类型：`boolean`
- 默认值：`false`

回车和Tab按键切换焦点时不允许重新回到第一个位置



### keyDownSelectContent
- 类型：`boolean`
- 默认值：`false`

键盘tab或者enter激活单元格后，是否选中单元格内容



### cellValueFillByDrag
- 类型：`boolean`
- 默认值：`false`

拖拽单元格填充值

 ![单元格拖拽赋值](/docs/grid-cell-drag-fill.png)


### field
- 类型：`string`
- 默认值：`'html'`

字段渲染方式，可选text||html，字段中也可配置
```javascript
{
    renderType: 'html',
}
```



### allowMultiColSort
- 类型：`boolean`
- 默认值：`false`

允许多列排序



### copyContent
- 类型：`boolean`
- 默认值：`true`

是否允许复制文本



### dataCopy
- 类型：`boolean`
- 默认值：`false`

是否开启复制数据到excel,copyContent为true时才能设置生效



### hideCopyAndPasteButton
- 类型：`boolean`
- 默认值：`true`

是否隐藏右键菜单弹框里的全选复制粘贴按钮



### headerFilterConfig
- 类型：`object`
- 默认值：`null`

表头快捷查询配置，配置后，会覆盖全局配置

 ```javascript
 // 默认配置如下:
 {
     number: {
         // 是否支持区间检索
         range: false,
         // 匹配规则可选:大于等于、小于等于['NGOE','NLOE']||大于、小于['NG','NL']
         match: ['NGOE', 'NLOE'],
         // 是否允许清空 boolean true
         allowClear: true,
     },
     dateTime: {
         // 起始时间默认时分秒
         startTime: '00:00:00',
         // 终止时间默认时分秒
         endTime: '23:59:59',
     },
     text: {
         // 提示文本
         placeholder: '',
         // 是否允许清空 boolean true
         allowClear: true,
     },
     select: {
         // 是否开启全选
         showAllSelect: false,
         // 显示搜索框的下拉选项个数
         searchThreshold: 50,
     },
 }
  ```


### compare
- 类型：`boolean`
- 默认值：`true`

是否对比前后两次的查询条件



### noRecordText
- 类型：`string`
- 默认值：`暂无数据`

表格无数据时展示的文字



### showClickCellBorder
- 类型：`boolean`
- 默认值：`false`

点击（双击）单元格时是否显示当前单元格的边框



### recordTotalAsync
- 类型：`boolean`
- 默认值：`false,`

是否异步显示记录总数。开启后，查询不显示总记录数量，点击总条数时才显示，用于提升大数据加载性能



### onExcelPaste
- 类型：`(excelData)=>void`
- 默认值：`null`

从Excel文件中复制内容粘贴到表格事件

 ::: tip 提示
 其中excelData为二维数组，对应Excel的行与列
 :::


### onBeforeRefresh
- 类型：`function`
- 默认值：`null`

刷新之前



### onBeforeLoad
- 类型：`(data:object[])=>data`
- 默认值：`null`

数据加载之前，可格式化即将加载的数据



### onCellClick
- 类型：`Function`
- 默认值：`null`

单元格点击事件



### onRendered
- 类型：`()=>void`
- 默认值：`null`

组件渲染成功之后



### onRowActive
- 类型：`(row)=>void`
- 默认值：`null`

点击行的激活事件



### onBeforeRowActive
- 类型：`(row:object)=>boolean`
- 默认值：`null`

行激活之前，若返回false，则不激活当前行



### onColumnActive
- 类型：`(column)=>void`

列激活，columnsSelect:true开启选中列功能后，此事件才有效



### onSelect
- 类型：`(row:Object)=>void`
- 默认值：`null`

行选中



### onUnSelect
- 类型：`(row:Object)=>void`
- 默认值：`null`

取消行选中



### onAllSelect
- 类型：`()=>void`
- 默认值：`null`

全选



### onUnAllSelect
- 类型：`()=>void`
- 默认值：`null`

取消全选



### onLoadSuccess
- 类型：`(data:object[])=>void`
- 默认值：`null`

数据加载成功之后



### onBeforeUpdate
- 类型：`(data,`
- 默认值：`keys)=>boolean|data`

自动保存时，单元格保存之前的事件。返回false，则终止保存操作;可在此格式化保存的数据

 ```javascript
 // 终止自动保存
 onBeforeUpdate: function(data, fields) {
     return false;
 },
 // 对自动保存的数据格式化，增加name字段
 onBeforeUpdate: function(data, fields) {
     data.name = '张三';
     return data;
 },
 ```


### onUpdated
- 类型：`()=>void`
- 默认值：`null`

自动保存时，单元格的值保存成功之后的事件



### onBeforeDelete
- 类型：`(selections:object[])=>void`
- 默认值：`null`

删除之前



### onBeforeActivate
- 类型：`(selections:object[])=>void`
- 默认值：`null`

启用之前



### onBeforeSuspend
- 类型：`(selections:object[])=>void`
- 默认值：`null`

停用之前



### onCellDbClick
- 类型：`()=>void`
- 默认值：`null`

单元格双击事件



### onValidating
- 类型：`()=>{result:boolean,message:string}`
- 默认值：`null`

校验事件，可在此自定义校验规则

 ```javascript
 {
     onValidating: function(data) {
         if (data.name !== 'test') {
             return {result: false, message: '校验失败'}
         }
     }
 }
 ```


### onColumnsWidthChange
- 类型：`()=>void`
- 默认值：`null`

列宽改变事件



### onLoadFail
- 类型：`()=>void`
- 默认值：`null`

数据加载失败



### onHeaderClick
- 类型：`()=>void`
- 默认值：`null`

表头点击事件



### onBeforeHeadRequest
- 类型：`(headRequestData:object)=>boolean`
- 默认值：`null`

快捷查询触发请求前，若返回false，则终止快捷查询请求



### onGroupSelect

分组勾选



### onGroupUnSelect

分组取消勾选



### onBeforeFixHeaderColumn
- 类型：`null`

冻结列表头冻结之前触发,用于表头列属性，(column)=>column



### onDrag
- 类型：`(event:{rowData:object,oldIndex:number,newIndex:number})=>void`
- 默认值：`null`

拖拽行改变顺序之后触发



### refreshTotalMap
- 类型：`(totalMap:`
- 默认值：`object)=>void`

刷新表格计算总数的方法



### upAndDownCycleActive
- 类型：`boolean`
- 默认值：`false`

是否开启上下键循环激活行



### onFilterKeydown
- 类型：`(keyCode)=>void`

表头快捷查询keydown事件，目前支持text和number可输入类型字段的快捷查询



### showMultipleConfigs
- 类型：`boolean`
- 默认值：`false`

是否开启表格列多个配置



### fitContent

开启后，所有列都在当前页面显示，且占满整个页面，



### allowCellRangeSelect
- 类型：`boolean`
- 默认值：`false`

是否选择单元格，类似Excel单元格选中效果，按CTRL+C可将内容复制到剪贴板



### lazyLoad
- 类型：`boolean`
- 默认值：`true`

数据是否懒加载



### defaultLinkText

默认link字段的显示内容



### onUpdateFailed
- 类型：`()`
- 默认值：`=>`

自动保存接口错误时触发



### disableHorizontalDrag
- 类型：`boolean`
- 默认值：`true`

禁止横向拖拽（在cellValueFillByDrag为true的时候生效）



### sortHeaderFirst
- 类型：`Boolean`
- 默认值：`false`

优先使用表头点击排序



### autoSaveOnDrag
- 类型：`Boolean`
- 默认值：`true`

执行拖拽的时候，是否自动保存


## 方法

### setOptions(option)
 - 参数：{object} option

动态修改options参数
 ```javascript
 // 动态调整url
 grid.setOptions({url: Gikam.IFM_CONTEXT+'/core/user/queries'})
 ```


### getOptions()
 - 返回值：{object}

获取配置参数


### loadData(data, param)
 - 参数：{object[]} data

加载数据


### cleanData()

清空表格数据


### refresh(param, editorCell, firstDataDeferred)
 - 参数：{object} param
 - 返回值：{Deferred}

刷新数据，调用此方法可同步修改url、requestDat等参数
 ```javascript
 grid.refresh({
     url: Gikam.IFM_CONTEXT + '/core/xxx',
     requestData: {
         field: 'name',
         match: 'SC',
         value: 'test',
     },
 });
 ```


### getSelections()
 - 返回值：{object[]}

获取选中的数据


### refreshRowByIndex(dataIndex)
 - 参数：{number} index
 - 返回值：{Deferred}

通过索引刷新指定数据


### refreshRowById(id)
 - 参数：{string|number|array} id
 - 返回值：{Deferred}

通过id刷新一条数据


### deleteRows(url, selectRows, param)
 - 参数：{string} url
 - 返回值：{Object}

调用接口，删除选中数据


### suspendRows(url)
 - 参数：{string} url
 - 返回值：{Deferred}

调用接口停用选择的数据


### unsuspendRows(url)
 - 参数：{string} url
 - 返回值：{Deferred}

调用接口取消停用选择的数据


### exportExcel(...arg)
 - 参数：{string} fileName 文件名称
 - 参数：{string} rows 导出接口url
 - 参数：{boolean} rows 是否导出选择的数据，false时导出本页数据

导出Excel文件


### getActivedRow()
 - 返回值：{object}

获取激活的行数据


### getActivedColumn()
 - 返回值：{object}

获取激活的列参数


### validate(data, isSilent = false)
 - 参数：{object[]} data 校验指定的数据，此参数可以不传，不传时对当前所有数据进行校验
 - 返回值：{boolean}

校验表格中数据是否满足规则，也可以校验指定行数据
 ```javascript
 // 给id为1的行，设置name值
 grid.setData({ id: 1, name: 'test' });
 // 给index第1行，设置name值
 grid.setData({ index: 1, name: 'test' });
 ```


### insert(url, data, param)
 - 参数：{string} url 接口地址
 - 参数：{object} data 即将新增的数据
 - 参数：{object} param 向接口中传入的param
 - 返回值：{Deferred}

调用接口新增一条数据


### moveUp(url, orderField)
 - 参数：{string} url 上移接口
 - 返回值：{Deferred}

将选中数据上移


### moveDown(url, orderField)
 - 参数：{string} url 下移接口
 - 返回值：{Deferred}

将选中数据下移


### activeRowByIndex(index)
 - 参数：{number} index
 - 参数：{boolean} [scroll=true] 是否滚动到激活行

通过索引激活行


### checkAll()

选中全部数据


### unCheckAll()

取消选中全部数据


### selectRowByIndex(index)
 - 参数：{number} index

通过行索引选择数据


### unSelectRowByIndex(index)
 - 参数：{number} index

通过行索引取消选择数据


### selectRowById(id)
 - 参数：{number|string} id

通过id选择一条数据


### unSelectRowById(id)
 - 参数：{number|string} id

通过id取消选择一条数据


### selectRowByIdList(keys)
 - 参数：{(number|string)[]} idList

通过id数组，批量选择数据


### setColumnsEditor(columns, editor = true)
 - 参数：{array} columns
 - 参数：{boolean} editor

切换字段编辑状态


### setReadonly(isReadonly)
 - 参数：{boolean} isReadonly

使得整个表格只读


### hideBody()
 - 返回值：{grid}

隐藏表格数据部分
 ```javascript
 // 第一行的field1、field2字段只读
 grid.toFieldsReadonly(0, ['field1,'field2'])
 ```

 ```javascript
 // 第一行的field1、field2字段可编辑
 grid.toFieldsEdit(0, ['field1,'field2'])
 ```



### showBody()
 - 返回值：{grid}

显示表格数据部分


### hideColumns(fields)
 - 参数：{string[]} fields 列名称

隐藏指定列


### showColumns(fields)
 - 参数：{string[]} fields 列名称

显示指定的列


### setHidden(arg)
 - 参数：{Boolean} 隐藏 true,

隐藏或显示当前grid


### removeFieldsValidator(fields, validators)
 - 参数：{string[]} fields 需要清除验证的fields字段
 - 参数：{sting[]} validators 需要清除验证内容

移除指定字段的校验器
 ```javascript
 // 移除field1字段的非空校验器
 grid.removeFieldsValidator(['field1'], ['notEmpty'])
 ```


### addFieldsValidator(fields, validators)
 - 参数：{array} fields 需要增加验证的fields字段,
 - 参数：{array} validators 需要增加验证内容,

给指定字段添加校验器


### refreshColumns(columns, scrollLeftToStart = true, keepPrevState = false)
 - 参数：{object[]} columns 新的字段数组
 - 返回值：{Deferred}

动态刷新表格列


### getField(index, field)
 - 参数：{number|string} index 所在行
 - 参数：{String} fieldName 所在列对应的field字段

获取单元格编辑器


### getHeadField(field)
 - 参数：{string} fieldName
 - 返回值：{object}

获取表头快捷查询编辑器


### getColumn(fieldName)
 - 参数：{string} fieldName
 - 返回值：{object}

获取指定的列


### getIndexByDataId(dataId)
 - 参数：{number/String} dataId 数据id

通过数据id，获取索引


### focusField(dataIndex, fieldName)
 - 参数：{number|string} dataIndex 所在行
 - 参数：{String} fieldName 字段名称

激活单元格组件


### refreshGroup(options)
 - 参数：{object} param 分组参数，具体参考[group](#group)

根据传入的参数，重新刷新Grid分组


### refreshContextmenu(menu)
 - 参数：{object[]} menu 菜单列表,具体参考[contextmenu](#contextmenu)

刷新右键菜单


### pageSearchGrid()

前端筛选


### selectLatestSelectedRow(param = { triggerEvent: true })

数据重新加载后，选择加载前已选择的数据


### activateLatestActivatedRow()

数据重新加载后，激活加载前激活的行数据


### activeRowById(id)
 - 参数：{string|number} id
 - 参数：{boolean} [scroll=true] 是否滚动到激活行

通过id激活行


### getActiveEditor()

获取当前正在操作的单元格编辑器


### showToolbar()

显示工具栏


### hideToolbar()

隐藏工具栏


### scrollToBottom()

滚动条至底部


### scrollToRight()

滚动条至最右侧


### getSumData()

获取合计值对象


### scrollToRowId(rowDataId)
 - 参数：{string|number} rowDataId

将滚动条滚动到指定数据位置


### setActivedColumn(index)
 - 参数：{number} index

根据索引激活列


### cleanActivedColumn()
 - 参数：{number} index

清空选中的列


### refreshToolbar(toolbar)
 - 参数：{object} 参照[toolbar](#toolbar)配置

刷新工具栏


### cleanRequestData(ignoreKeys = [])
 - 参数：{string[]} [ignoreKeys=[]] 忽略清空指定的字段

undefined


### cleanHeadRequestData()

清空快捷查询条件值


### getHeadRequestData()
 - 返回值：{object}

获取快捷查询条件值


### cleanOrderData(ignoreKeys = [])

清空排序条件


### getRowDataById(id)
 - 参数：{string|number} id

通过id获取行数据


### setCellStyle(dataIndex, style, fields = [])
 - 参数：{number} rowIndex 行索引
 - 参数：{object} style 样式，例如：{backgroundColor:"#fff"}
 - 参数：{string[]} fields 单元格对应的字段数组

给指定单元格设置样式


### cleanStettedCellStyle()

清空通过setCellStyle设置的样式


### enableSelection(type = 'checkbox')
 - 参数：{string} [type='checkbox']

启用选择功能


### disableSelection()

禁用选择功能


### refreshSilent()

静默刷新，没有加载中的效果


### changeGroupExpandStateById(id, expand)
 - 参数：{string|number} id 分组行数据ID
 - 参数：{boolean} expand 是否展开

通过分组行ID，展开或折叠分组


### loadDataSilent(data)
 - 参数：{object[]} data

静默方式加载数据


### cleanSelection()

清空选择数据


### openAdvancedSearch()

打开高级搜索


### closeAdvancedSearch()

关闭高级搜索


