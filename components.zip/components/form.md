---
sidebarDepth: 1
---

# Form 表单<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#form-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### columns
- 类型：`number`
- 默认值：`2`

表单默认总列数

 ::: warning 注意
 字段中的colspan可设置的最大置值不能超过columns
 :::


### fields
- 类型：`object[]`
- 默认值：`[]`

字段列表



### panels
- 类型：`object[]`
- 默认值：`[]`

表单字段分组



### data
- 类型：`object`
- 默认值：`{}`

表单中的填充值，如果设置了url，则此属性无效



### titleWidthAuto
- 类型：`boolean`
- 默认值：`false`

字段中的标题是否根据标题内容自适应宽度

 ::: warning 注意
 如何设置此属性为true，标题会在垂直方向上`左右不对齐`
 :::


### titleAlign
- 类型：`'left'|'right'|'center'`
- 默认值：`'left'`

标题水平对齐方式



### service
- 类型：`string`
- 默认值：`null`

接口中对应的service实现类名称，首字母需要小写

 ::: tip 提示
 该属性会在自动保存时，指定调用哪个服务进行逻辑处理，一般不需要设置
 :::


### autoSave
- 类型：`boolean`
- 默认值：`true`

是否开启自动保存，开启后，鼠标失焦时即调用保存接口

 ::: tip 提示
 若不开启自动保存，则需要通过表单的getData方法获取数据，手动调用接口进行保存
 :::


### border
- 类型：`boolean`
- 默认值：`false`

是否显示表单外层边框



### margin
- 类型：`boolean`
- 默认值：`false`

是否显示表单外边距8px



### caption
- 类型：`object`
- 默认值：`{}`

表单顶部显示提示文字

 ```javascript
 // 设置提示文本
 caption: {
     text: '表单提示文字，显示在顶部'
 }
 ```
 ![表单提示](/docs/form-caption.png)


### dbTable
- 类型：`string`
- 默认值：`null`

后台数据库表名，在调用附件上传时使用



### layout
- 类型：`'vertical'|'inline'`
- 默认值：`'inline'`

表单布局，有时标题太长无法显示完整，可设置为'vertical'方向



### titleWidth
- 类型：`number`
- 默认值：`100`

标题默认宽度

 ::: tip 提示
 若开启titleWidthAuto，则titleWidth不生效，标题宽度为内容宽度
 :::


### hidden
- 类型：`boolean`
- 默认值：`false`

表单初始化时是否隐藏



### instantSavePath
- 类型：`string`
- 默认值：`null`

自动保存时的接口地址

 ::: tip 提示
 该属性一般不需要配置，只要按照规范开发接口，配置url后，后台会在数据查询后，
 将保存路径设置到`response`中，其key为`GIKAM-INSTANT-SAVE-PATH`，
 若此路径不能满足个别业务场景，需要设置此属性值
 :::


### panelFoldable
- 类型：`boolean`
- 默认值：`false`

是否启用分组面板折叠功能



### defaultPanelExpand
- 类型：`boolean`
- 默认值：`true`

表单初始化时，是否展开所有分组面板



### copyContent
- 类型：`boolean`
- 默认值：`true`

是否允许复制文本



### tabMoveDirection
- 类型：`'LeftRight'|'UpDown'`
- 默认值：`'LeftRight'`

Tab键通过哪种移动方向激活字段，左右移动还是上下移动



### onLoadSuccess
- 类型：`(data:object)=>void`
- 默认值：`null`

数据加载成功后的事件



### onRendered

组件渲染成功后事件



### onInserted
- 类型：`(id:string||number)=>void`
- 默认值：`null`

自动保存新增数据后



### onUpdated
- 类型：`(id:string||number)=>void`
- 默认值：`null`

自动保存修改数据后



### onBeforeUpdate
- 类型：`(data,`
- 默认值：`keys)=>boolean`

自动保存修改数据之前



### onValidating
- 类型：`(data:object)=>object{result:true|false,message:''}`
- 默认值：`null`

自定义校验提示



### onTitleClick
- 类型：`(data,title)=>void`
- 默认值：`null`

点击字段标题触发的事件



### onBeforeRefresh
- 类型：`()=>void|boolean`
- 默认值：`null`

刷新之前



### onKeyDown
- 类型：`(event:Event)`
- 默认值：`=>`

键盘事件



### enableAuditModifyReason
- 类型：`boolean`
- 默认值：`true`

开启审计跟踪录入原因


## 方法

### getData()
 - 返回值：{Object}

获取表单数据


### setData(data, saveFlag = true)
 - 参数：{Object} data -
 - 参数：{boolean} saveFlag -

设置数据并可选择性地保存


### cleanValidateCache()

清除校验字段缓存


### refresh(param = {}, cleanFlag = true)
 - 参数：{Object} param -
 - 参数：{boolean} cleanFlag -
 - 返回值：{Promise}

刷新组件数据的方法


### refreshFields(param, refreshAll = false)
 - 参数：{Array} param -
 - 参数：{boolean} refreshAll -
 - 返回值：{Object}

刷新表单中的字段，替换原有的字段列表
 ```javascript
 var form = Gikam.getComp('formId');

 // 刷新没有分组的字段
 form.refresh([
     { title: '新字段一', field: 'field1' },
     { title: '新字段二', field: 'field2' },
 ]).done(function() {
     Gikam.alert('刷新成功');
 });

 // 刷新分组的字段
 form.refresh([
     {
         title: '分组面板一',
         fields: [
             { title: '新字段一', field: 'field1' },
             { title: '新字段二', field: 'field2' },
         ],
     },
 ]).done(function() {
     Gikam.alert('分组表单字段刷新成功');
 });
 ```


### loadData(data, deep = true)
 - 参数：{Object} data -
 - 参数：{boolean} deep -

表单没有配置URL时，通过该方法对表单进行赋值


### setOptions(param)
 - 参数：{Object} param -

设置选项


### getOptions()
 - 返回值：{Object}

获取选项


### validate(isSilent = false, param = { validateMultiple: false })
 - 参数：{boolean} [isSilent=false] 是否静默校验，如果是true，则不弹框提示
 - 参数：{object} [param={validateMultiple:false}] 是否提示全部校验字段，默认false，优先提示第一个校验字段
 - 返回值：undefined

表单校验


### toFieldsReadonly(fields)
 - 参数：{string[]} fields 只读的字段名称

设置字段只读，需要确保表单加载完成之后调用该方法
 ```javascript
 var form = Gikam.getComp('formId');
 form.toFieldsReadonly(['field1','field2'])
 ```


### toFieldsEdit(fields)
 - 参数：{string[]} fields

设置字段可编辑，需要确保表单加载完成之后调用该方法
 ```javascript
 var form = Gikam.getComp('formId');
 form.toFieldsEdit(['field1','field2'])
 ```


### removeFieldValidator(field, validators)
 - 参数：{string} field 字段名称
 - 参数：{string[]} validators 移除的校验器名称

移除指定字段的校验器
 ```javascript
 // 如下为去除field1字段的非空、数字范围校验
 form.removeFieldValidator('field1', ['notEmpty','numRange'])
 ```


### addFieldValidator(field, validators = [])
 - 参数：{string} field 字段名称
 - 参数：{array} validators 增加的校验器

增加指定字段的校验器
 ```javascript
 // 如下为给field1字段添加非空和数字范围校验
 form.addFieldValidator('field1', ['notEmpty','numRange'])
 ```


### setSelectOptions(field, list)
 - 参数：{string} field -
 - 参数：{Array} list -

设置选择控件的选项


### getField(fieldName)
 - 参数：{string} fieldName -

根据字段名称获取编辑器管理器中的相应字段


### showFields(fields)
 - 参数：{string[]} fields 字段名称

显示字段
 ```javascript
 form.showFields(['field1','field2'])
 ```


### hideFields(fields)
 - 参数：{string[]} fields

隐藏字段
 ```javascript
 form.hideFields(['field1','field2'])
 ```


### hidePanelById(id)
 - 参数：{string} id 分组面板的id

通过id隐藏指定的分组面板


### showPanelById(id)
 - 参数：{string} id 分组面板的id

通过id显示指定的分组面板


### setHidden(isHidden)
 - 参数：{boolean} false隐藏，true时显示

隐藏或显示当前form


### scrollToByPanelId(panelId)
 - 参数：{panelId} 分组面板id

滚动条滚动至指定的panel位置


### cleanData()
 - 返回值：Deferred

清空表单数据


### setReadonly(readonlyFlag)
 - 参数：{*} readonlyFlag

表单只读


### changeCaptionText(text)
 - 参数：{string} 动态信息

动态设置提示信息


### togglePanelIds(ids, isExpand = true)
 - 参数：{Array} panel的id集合
 - 参数：{Boolean} 是否展开

动态设置panel展示收起状态


### togglePanels(isExpand = true)
 - 参数：{Boolean} 是否展开

表单中整个panel展示收起状态


