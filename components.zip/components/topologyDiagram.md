---
sidebarDepth: 1
---

# TopologyDiagram 拓扑图<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#topologyDiagram-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### data
- 类型：`object`
- 默认值：`null`

流程绘制数据



### readonly
- 类型：`boolean`
- 默认值：`false`

是否只读



### configShape

配置图形



### lineName
- 类型：`'curve'|'polyline'|'line'`
- 默认值：`'polyline'`

连线样式



### fromArrowType
- 类型：`'empty'|'triangleSolid'|'triangle'|'diamondSolid'|'diamond'|'circleSolid'|'circle'|'line'|'lineUp'|'lineDown'`
- 默认值：`'empty'`

连线起点形状



### toArrowType
- 类型：`'empty'|'triangleSolid'|'triangle'|'diamondSolid'|'diamond'|'circleSolid'|'circle'|'line'|'lineUp'|'lineDown'`
- 默认值：`'empty'`

连线尾点形状



### fullScreen
- 类型：`boolean`
- 默认值：`false`

是否显示全屏



### exportImg
- 类型：`boolean`
- 默认值：`false`

是否显示导出按钮



### customTools
- 类型：`object[]`
- 默认值：`[]`

自定义节点形状



### commonTools
- 类型：`object[]`
- 默认值：`[]`

给默认图形增加属性配置



### bkColor
- 类型：`string`
- 默认值：`null`

画板背景色，必须为16进制



### backgroundImageUrl
- 类型：`string`
- 默认值：`null`

画板背景图片地址



### onRendered
- 类型：`()=>void`
- 默认值：`null`

加载成功事件



### onNodeDbClick
- 类型：`()=>void`
- 默认值：`null`

节点双击事件



### onMoveInNode
- 类型：`()=>void`
- 默认值：`null`

鼠标进入节点事件



### onMoveInLine
- 类型：`()=>void`
- 默认值：`null`

鼠标进入连线事件



### onContextmenu
- 类型：`(node)=>`
- 默认值：`[{text:`

鼠标右键事件



### onSave
- 类型：`(data,svg)=>void`
- 默认值：`null`

点击保存的事件，在此事件里调用接口保存数据


## 方法

### setData(data)
 - 参数：{object} data

设置流程图数据


### setReadonly(readonly)
 - 参数：{boolean} readonly 是否只读

设置只读和可编辑


### setBkColor(color)
 - 参数：{string} color 16进制

设置画布背景色


### cleanAllAnimation()

清空所有节点动画


### setNodeAnimation(callback, animationType)
 - 参数：{(node)=>boolean} callback 返回false，则不设置动画效果
 - 参数：{'upDown'|'leftRight'|'heart'|'success'|'warning'|'error'|'show'} animationType

给所有节点添加动画效果


### addNodeAnimation(node, animationType)
 - 参数：{object} node
 - 参数：{'upDown'|'leftRight'|'heart'|'success'|'warning'|'error'|'show'} animationType

给指定节点增加动画效果


## 应用

### 拓扑图配置示例

```javascript
Gikam.create('layout', {
    center: {
        items: [{
            type: 'diagramDraw',
            id: 'topology-diagram',
            lineName: 'polyline',
            fromArrowType: 'diamond',
            toArrowType: 'diamond',
            // 自定义图形
            customTools: [{
                image: '/img/logo.svg',
                data: [{ key: '时间', value: '' },
                { key: '作者', value: '22', type: 'textarea', height: 60 }]
            }, {
                image: '/img/logo-blue.svg',
                data: [{ key: '太阳', value: '11' },
                { key: '大小的', value: '' }]
            }],
            // 给默认图形增加配置属性
            commonTools: [
                {
                    icon: 'icon-circle',
                    data: [{ key: '圆1', value: '11' },
                    { key: '圆2', value: '' }]
                }, {
                    icon: 'icon-triangle',
                    data: [{ key: '三角', value: '三角' },
                    { key: '三角2', value: '' }]
                }, {
                    data: [{ key: '所有1', value: '所有12123' },
                    { key: '所有2', value: '12313' }]
                }],
                data: '{"pens":[{"id":"00d8cd0b","name":"rectangle","tags":[],"rect":{"x":94,"y":80,"width":100,"height":50,"center":{"x":144,"y":105},"ex":194,"ey":130},"lineWidth":1,"rotate":0,"offsetRotate":0,"globalAlpha":1,"dash":0,"strokeStyle":"#222","fillStyle":"","font":{"color":"#222","fontFamily":"Arial","fontSize":12,"lineHeight":1.5,"fontStyle":"normal","fontWeight":"normal","textAlign":"center","textBaseline":"middle","background":""},"animateStart":0,"animateCycleIndex":0,"lineDashOffset":0,"text":"圆角矩形","textOffsetX":0,"textOffsetY":0,"animateType":"","data":[{"key":"颜色6","value":"6666"},{"key":"地球7","value":"777"}],"zRotate":0,"anchors":[{"x":94,"y":105,"direction":4},{"x":144,"y":80,"direction":1},{"x":194,"y":105,"direction":2},{"x":144,"y":130,"direction":3}],"rotatedAnchors":[{"x":94,"y":105,"direction":4},{"x":144,"y":80,"direction":1},{"x":194,"y":105,"direction":2},{"x":144,"y":130,"direction":3}],"animateDuration":0,"animateFrames":[],"borderRadius":0.1,"iconSize":null,"imageAlign":"center","gradientAngle":0,"gradientRadius":0.01,"paddingTop":10,"paddingBottom":10,"paddingLeft":10,"paddingRight":10,"paddingLeftNum":10,"paddingRightNum":10,"paddingTopNum":10,"paddingBottomNum":10,"textRect":{"x":104,"y":112.5,"width":80,"height":7.5,"center":{"x":144,"y":116.25},"ex":184,"ey":120},"fullTextRect":{"x":104,"y":90,"width":80,"height":30,"center":{"x":144,"y":105},"ex":184,"ey":120},"iconRect":{"x":104,"y":90,"width":80,"height":17.5,"center":{"x":144,"y":98.75},"ex":184,"ey":107.5},"fullIconRect":{"x":104,"y":90,"width":80,"height":30,"center":{"x":144,"y":105},"ex":184,"ey":120},"time":"111"},{"id":"5e8a9ee1","name":"image","tags":[],"rect":{"x":218,"y":107,"width":100,"height":100,"center":{"x":268,"y":157},"ex":318,"ey":207},"lineWidth":1,"rotate":0,"offsetRotate":0,"globalAlpha":1,"dash":0,"strokeStyle":"#222","fillStyle":"","font":{"color":"#222","fontFamily":"Arial","fontSize":12,"lineHeight":1.5,"fontStyle":"normal","fontWeight":"normal","textAlign":"center","textBaseline":"middle","background":""},"animateStart":0,"animateCycleIndex":0,"lineDashOffset":0,"text":"","textOffsetX":0,"textOffsetY":0,"animateType":"","data":[{"key":"时间","value":"2020-03-13"},{"key":"作者","value":"小红666"},{"key":"字数","value":14}],"zRotate":0,"anchors":[{"x":218,"y":157,"direction":4},{"x":268,"y":107,"direction":1},{"x":318,"y":157,"direction":2},{"x":268,"y":207,"direction":3}],"rotatedAnchors":[{"x":218,"y":157,"direction":4},{"x":268,"y":107,"direction":1},{"x":318,"y":157,"direction":2},{"x":268,"y":207,"direction":3}],"animateDuration":0,"animateFrames":[],"borderRadius":0,"iconSize":null,"image":"https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2534506313,1688529724&fm=26&gp=0.jpg","imageAlign":"center","gradientAngle":0,"gradientRadius":0.01,"paddingTop":0,"paddingBottom":0,"paddingLeft":0,"paddingRight":0,"paddingLeftNum":0,"paddingRightNum":0,"paddingTopNum":0,"paddingBottomNum":0,"textRect":{"x":218,"y":189,"width":100,"height":18,"center":{"x":268,"y":198},"ex":318,"ey":207},"fullTextRect":{"x":218,"y":107,"width":100,"height":100,"center":{"x":268,"y":157},"ex":318,"ey":207},"iconRect":{"x":218,"y":107,"width":100,"height":77,"center":{"x":268,"y":145.5},"ex":318,"ey":184},"fullIconRect":{"x":218,"y":107,"width":100,"height":100,"center":{"x":268,"y":157},"ex":318,"ey":207},"img":{},"lastImage":"https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=2534506313,1688529724&fm=26&gp=0.jpg","imgNaturalWidth":500,"imgNaturalHeight":375,"time":"33"},{"id":"80e65d8e","name":"polyline","tags":[],"rect":{"x":0,"y":0,"width":0,"height":0,"center":{"x":0,"y":0},"ex":0,"ey":0},"lineWidth":1,"rotate":0,"offsetRotate":0,"globalAlpha":1,"dash":0,"strokeStyle":"#222","fillStyle":"","font":{"color":"","fontFamily":"Arial","fontSize":12,"lineHeight":1.5,"fontStyle":"normal","fontWeight":"normal","textAlign":"center","textBaseline":"middle","background":"#fff"},"animateStart":0,"animateCycleIndex":0,"locked":false,"textOffsetX":0,"textOffsetY":0,"controlPoints":[{"x":144,"y":168,"direction":3,"anchorIndex":3,"id":"00d8cd0b"},{"x":144,"y":257},{"x":268,"y":257,"direction":3,"anchorIndex":3,"id":"5e8a9ee1"}],"fromArrowSize":5,"toArrowSize":5,"borderWidth":0,"borderColor":"#000000","animateColor":"","animateSpan":1,"animatePos":0,"isAnimate":false,"animateFromSize":0,"animateToSize":0,"animateDotSize":3,"fromArrow":"diamond","from":{"x":144,"y":130,"direction":3,"anchorIndex":3,"id":"00d8cd0b"},"textRect":null,"to":{"x":268,"y":207,"direction":3,"anchorIndex":3,"id":"5e8a9ee1"},"toArrow":"diamond"}],"lineName":"polyline","fromArrowType":"diamond","toArrowType":"diamond","scale":1,"locked":0}',
                onSave(data, svg) {
                    Gikam.info(data)
                    Gikam.info(svg) 
                },
                onNodeDbClick(data) {
                    console.info(data);
                }
            }]
        },
        renderTo: workspace.window.$dom,
    });
    // 如下每5秒随机给节点设置随机动画
    var array = ['heart', 'success', 'error', 'show', 'leftRight']
    setInterval(function () {
        var i = parseInt(Math.random() * 5);
        var j = parseInt(Math.random() * 2);
        Gikam.getComp('topology-diagram').setNodeAnimation(function (node, index) {
            // 返回true则设置相应动画效果
            if (j === index) {
                return true
            }
            return false;
        }, array[i]);
    }, 5 * 1000);
```
![topology](/docs/topology.png)
