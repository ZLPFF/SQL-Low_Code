---
sidebarDepth: 1
---

# Modal 弹窗<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#modal-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件ID



### title
- 类型：`string`
- 默认值：`null`

弹窗标题



### titleStyle
- 类型：`object`
- 默认值：`null`

设置标题样式



### width
- 类型：`string|number`
- 默认值：`'80%'`

默认宽度



### height
- 类型：`string|number`
- 默认值：`'80%'`

默认高度



### url
- 类型：`string`
- 默认值：`null`

嵌入的页面地址



### src
- 类型：`string`
- 默认值：`null`

通过iframe嵌入的页面地址



### showCloseBtn
- 类型：`boolean`
- 默认值：`true`

显示关闭按钮



### showMaxBtn
- 类型：`boolean`
- 默认值：`true`

显示最大化按钮



### showMinBtn
- 类型：`boolean`
- 默认值：`true`

显示最小化按钮



### animation
- 类型：`boolean`
- 默认值：`true`

打开弹框时是否有动画效果



### bodyStyle
- 类型：`object`
- 默认值：`null`

设置弹框中body样式



### data
- 类型：`object`
- 默认值：`null`

用于自定义数据，定义的数据可以在嵌入的页面中通过`Gikam.getLastModal().getData()`获取



### isModal
- 类型：`boolean`
- 默认值：`true`

是否模态对话框，false时可操作弹框下层的内容



### items
- 类型：`object[]`
- 默认值：`[]`

设置弹框中子组件



### dragLimitation
- 类型：`boolean`
- 默认值：`false`

拖拽时是否禁止超出容器外



### enabledAnimation

禁用弹框关闭动画，注意禁用后beforeClose方法将失效



### resizeWithWindow
- 类型：`boolean`
- 默认值：`true`

window尺寸变化后是否更改弹框宽高



### pageParam

向弹框页面中传递的参数，通过getLastModal().window.getPageParam()获取



### isFullScreen
- 类型：`boolean`
- 默认值：`false`

弹框是否全屏



### isMinimize
- 类型：`boolean`
- 默认值：`false`

弹框是否最小化



### targetId

关联DOM元素的id



### onResize
- 类型：`()=>void`
- 默认值：`null`

尺寸变化



### onAfterClose
- 类型：`()=>void`
- 默认值：`null`

关闭之后



### onBeforeClose
- 类型：`()=>boolean`
- 默认值：`null`

关闭之后，返回false，禁止关闭



### onMinBtnClick
- 类型：`()=>void`
- 默认值：`null`

最小化按钮点击



### onIframeLoad
- 类型：`()=>void`
- 默认值：`null`

若设置src后，Iframe中页面加载成功之后


## 方法

### openMask()

开启遮罩


### closeMask()

关闭遮罩


### getIframeDom()
 - 返回值：HTMLIFrameElement

获取iframe元素


### load()

重新加载页面


### close(data)
 - 参数：{object} data 调用afterClose事件时传递的数据

关闭弹框


### setHeaderCenter(htmlString)

设置弹框头部内容


### getData()

获取定义数据


### setData(data)

设置自定义数据


### onBeforeClose(callback)
 - 参数：{function} 回调方法

动态绑定关闭之前的事件
 ```javascript
 Gikam.getLastModal().onBeforeClose(function() {
     console.info('关闭之前');
 });
 ```


### setSize(width, height, left, top)
 - 参数：{number|string} width 宽度
 - 参数：{number|string} height 高度
 - 参数：{number|string} left 左
 - 参数：{number|string} top 上

动态设置弹框位置及大小


### setTitle(title)
 - 参数：{string} title

动态设置弹框标题


