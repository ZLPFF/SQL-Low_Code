---
sidebarDepth: 1
---

# ShuttleFrame 穿梭框<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#shuttleFrame-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### columns
- 类型：`object[]`
- 默认值：`null`

左右表格列，默认两表格列相同



### rightColumns
- 类型：`object[]`
- 默认值：`null`

右侧表格列



### data
- 类型：`object[]`
- 默认值：`[]`

左侧表格加载的数据



### rightData
- 类型：`object[]`
- 默认值：`[]`

右侧表格加载的数据



### filterOpen
- 类型：`boolean`
- 默认值：`true`

默认是否展开快捷查询



### leftGridUrl
- 类型：`string`
- 默认值：`null`

左侧表格数据源接口地址



### rightGridUrl
- 类型：`string`
- 默认值：`null`

右侧表格数据源接口地址



### leftHeadRequestData
- 类型：`object`
- 默认值：`null`

左侧表格快捷查询默认条件



### rightHeadRequestData
- 类型：`object`
- 默认值：`null`

右侧表格快捷查询默认条件



### leftRequestData
- 类型：`object`
- 默认值：`null`

左侧表格接口参数



### rightRequestData
- 类型：`object`
- 默认值：`null`

右侧表格接口参数



### delRepeatField
- 类型：`string`
- 默认值：`"id"`

数据的唯一标识字段，若两条数据该字段值相同，则认为是同一条数据



### page
- 类型：`boolean`
- 默认值：`false`

左右表格数据是否分页



### leftPage
- 类型：`boolean`
- 默认值：`true`

左侧表格数据是否分页



### rightPage
- 类型：`boolean`
- 默认值：`true`

右侧表格数据是否分页



### leftTitle
- 类型：`boolean`
- 默认值：`null`

左侧表格标题



### rightTitle
- 类型：`boolean`
- 默认值：`null`

右侧表格标题



### leftToolbar
- 类型：`object[]`
- 默认值：`[]`

左侧表格工具栏按钮



### rightToolbar
- 类型：`object[]`
- 默认值：`[]`

右侧表格工具栏按钮



### rightServerSearch
- 类型：`boolean`
- 默认值：`true`

右侧表格是否通过接口筛选数据



### leftServerSearch
- 类型：`boolean`
- 默认值：`true`

左侧表格是否通过接口筛选数据



### dblclickMove
- 类型：`boolean`
- 默认值：`true`

是否通过鼠标双击移动数据



### leftInitRequest
- 类型：`boolean`
- 默认值：`true`

左侧表格初始化时是否请求数据



### rightInitRequest
- 类型：`boolean`
- 默认值：`true`

右侧表格初始化时是否请求数据



### leftGeneralButtonGroupShow
- 类型：`boolean`
- 默认值：`true`

左侧列表通用按钮组是否展示



### rightGeneralButtonGroupShow
- 类型：`boolean`
- 默认值：`true`

右侧列表通用按钮组是否展示



### leftToolbarWrap
- 类型：`boolean`
- 默认值：`false`

左侧按钮是否可以换行



### rightToolbarWrap
- 类型：`boolean`
- 默认值：`false`

右侧按钮是否可以换行



### onAddClick
- 类型：`()=>void`
- 默认值：`null`

点击向右按钮时的事件，此事件是为了重写数据向右穿梭的逻辑



### onDelClick
- 类型：`()=>void`
- 默认值：`null`

点击向左按钮时的事件，此事件是为了重写数据向左穿梭的逻辑



### onBeforeAdd
- 类型：`()=>boolean`
- 默认值：`()=>true`

数据向右穿梭之前的事件，若返回false，则数据不会移动



### onBeforeDel
- 类型：`()=>boolean`
- 默认值：`()=>true`

数据向左穿梭之前的事件，若返回false，则数据不会移动



### onLeftLoadSuccess
- 类型：`()=>void`
- 默认值：`null`

左侧表格数据加载成功的事件



### onRightLoadSuccess
- 类型：`()=>void`
- 默认值：`null`

右侧表格数据加载成功的事件


## 方法

### cleanLeftHeadFilter()

清空左侧表格快捷查询条件


### cleanRightHeadFilter()

清空右侧表格快捷查询条件


### getSelectList()
 - 返回值：object[]

获取右侧表格的数据


