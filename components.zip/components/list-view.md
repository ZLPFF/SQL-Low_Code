---
sidebarDepth: 1
---

# ListView 标签列表<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#list-view-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### textField
- 类型：`string`
- 默认值：`'text'`

展示内容对应的字段



### requestData
- 类型：`object`
- 默认值：`{}`

请求接口所使用的参数



### itemWidth
- 类型：`number`
- 默认值：`150`

每条数据所占宽度



### checkbox
- 类型：`boolean`
- 默认值：`true`

是否展示复选框



### toolbar
- 类型：`Array`
- 默认值：`[]`

组件上方展示的按钮



### toolbarAlign
- 类型：`string`
- 默认值：`right`

按钮展示位置，right和left



### checkOnActive
- 类型：`boolean`
- 默认值：`true`

激活时是否选中复选框



### defaultIcon
- 类型：`'building|folder|cuvette|tube'`
- 默认值：`'building'`

默认标签



### data
- 类型：`array`
- 默认值：`[]`

展示需要的数据

 ```javascript
 [
    {
       id: '2',
       text: '列表2',
       icon : 'cuvette'
    }
 ]
 ```

## 方法

### refresh(param)
 - 参数：{ListViewOptions} [param]
 - 返回值：{Deferred}

通过url刷新


### setData(rows)
 - 参数：{ListViewItem[]} [rows]
 - 返回值：{Deferred}

手动赋值


### getSelections()

获取选中的数据


### activateItemById(id)
 - 参数：{ID} id

通过id激活某一项


### activateItemByIndex(index)
 - 参数：{number} [index]

通过序列激活某一项


### getActivatedItem()

获取激活的项的数据


### checkItemById(id)
 - 参数：{ID} [id]

通过id勾选项


### unCheckItemById(id)
 - 参数：{ID} [id]

通过id取消勾选项


