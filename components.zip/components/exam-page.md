---
sidebarDepth: 1
---

# Exam 考试组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#exam-page-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`dom`
- 默认值：`null`

渲染组件的位置



### questions
- 类型：`array`
- 默认值：`[]`

题目列表



### timeRemain
- 类型：`number`
- 默认值：`30`

考试时间，分钟



### buttonLeft
- 类型：`boolean`
- 默认值：`false`

组件按钮位置是否在左边



### mode
- 类型：`''|'practice'`
- 默认值：`''`

是否练习模式，练习模式有答案解析



### analysis
- 类型：`array`
- 默认值：`[]`

练习模式中的答案解析，tab标签是收缩的，需要手动展开



### showCountdown
- 类型：`boolean`
- 默认值：`true`

是否展示倒计时



### isShowPracticeAnalysis
- 类型：`Boolean`
- 默认值：`false`

是否展示试题解析，和mode:'practice'一起使用



### isShowOnOnceAgainButton
- 类型：`boolean`
- 默认值：`true`

错题页面是否展示再答一次按钮



### isShowBackButton
- 类型：`Boolean`
- 默认值：`false`

错题页面是否展示返回按钮，目前点击后的效果和再答一次效果一致



### answerTypeCategory
- 类型：`String`
- 默认值：`''`

题目类型下拉字段是否从数据库配置category中获取，类型不能改，只能改题目名称



### onEnding

//
```javascript
{
    '';
}
```


