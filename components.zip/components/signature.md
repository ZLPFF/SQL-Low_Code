---
sidebarDepth: 1
---

# Signature 电子签名<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#signature-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### showReason
- 类型：`boolean`
- 默认值：`false`

是否展示原因字段



### btnPosReverse
- 类型：`boolean`
- 默认值：`false`

组件按钮顺序是否调整



### userNameEditor
- 类型：`boolean`
- 默认值：`false`

用户名是否可编辑



### updateBulletName
- 类型：`string`
- 默认值：`''`

组件标题



### onConfirm
- 类型：`Function`
- 默认值：`null`

点击确认按钮操作



### onClosed
- 类型：`Function`
- 默认值：`null`

点击取消按钮的操作


