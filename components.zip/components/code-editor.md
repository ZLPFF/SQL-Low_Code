---
sidebarDepth: 1
---

# CodeEditor 代码编辑器<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#code-editor-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### value
- 类型：`string`
- 默认值：`null`

组件默认值



### height
- 类型：`string|number`
- 默认值：`300`

编辑器高度，如果适配父容器高度，则设置为'100%'



### language
- 类型：`'javascript'|'sql'|'java'|'shell'|'json'`
- 默认值：`'javascript'`

编辑的语言



### readonly
- 类型：`boolean`
- 默认值：`false`

是否只读



### theme
- 类型：`'vs'|'vs-dark'|'hc-black'`
- 默认值：`'vs'`

主题



### onChange
- 类型：`(value)=>`
- 默认值：`void`

change事件


## 方法

