---
sidebarDepth: 1
---

# Ckeditor4 富文本<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#ckeditor4-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件id



### readonly
- 类型：`boolean`
- 默认值：`false`

是否只读



### value
- 类型：`string`
- 默认值：`null`

默认值



### extraPlugins
- 类型：`string[]`
- 默认值：`[]`

自定义组件名称



### maxHeight
- 类型：`number`
- 默认值：`undefined`

编辑器最大高度



### height
- 类型：`number`
- 默认值：`undefined`

编辑器高度


## 应用

### 工具栏中自定制按钮

```javascript
// 在workspace的index.html中如下增加按钮
Gikam.component.Ckeditor4.onNamespaceLoaded = function(CKEDITOR) {
    CKEDITOR.plugins.add('refresh', {
        init: function(editor) {
            editor.addCommand('refresh', {
                exec: function(editor) {
                    console.info('逻辑', editor);
                },
            });
            editor.ui.addButton('refresh', {
                label: '重置',
                icon: Gikam.IFM_CONTEXT + 'refresh.png',
                command: 'refresh',
            });
        },
    });
};
// 使用ckeditor时配置extraPlugins:['refresh']
const options = {
    type: 'ckeditor4',
    extraPlugins: ['refresh'],
};
```
