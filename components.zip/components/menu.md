---
sidebarDepth: 1
---

# Menu 菜单<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#menu-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### mode
- 类型：`horizontal|vertical`
- 默认值：`horizontal`

展示模式



### items
- 类型：`object[]`
- 默认值：`[]`

菜单列表

 ```javascript
 菜单格式如下：
 [{ id: '00001', text: '菜单一', href: '/core/user/user-edit-list' }]
 ```


### cssStyle
- 类型：`CSSStyleDeclaration`
- 默认值：`{}`

样式


## 方法

### setItems(items)
 - 参数：{*} items

设置菜单列表


