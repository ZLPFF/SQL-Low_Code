---
sidebarDepth: 1
---

# Tab 标签页<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#tab-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### showIndex
- 类型：`number`
- 默认值：`0`

默认显示的标签索引



### height
- 类型：`number|string`
- 默认值：`'auto'`

组件高度，支持百分数、数字、像素字符串



### panels
- 类型：`object[]`
- 默认值：`[]`

页签面板

 ```javascript
 {
     type: 'tab',
     id: 'tab',
     panels: [
         {
             title: 'one',
             id: 'one',
             // 标签页上提示信息
             tip: '标签页提示信息',
             items: [
                 {
                     type: 'grid',
                     id: 'grid2',
                     data: [
                         {
                             id: 29,
                             field2: '字段值二',
                         },
                     ],
                     columns: [
                         {
                             checkbox: true,
                         },
                         {
                             title: '列二',
                             field: 'field2',
                         },
                     ],
                     onLoadSuccess: function() {
                         // 给第一个标签页设置数字角标
                         Gikam.getComp('tab').setPanelBadge('one', 20);
                     },
                 },
             ],
         },
         {
             title: 'two',
             id: 'two',
             items: [
                 {
                     type: 'button',
                     text: 'two',
                 },
             ],
         }
     ],
 },
 ```
 ![提示及角标](/docs/tab-tip.png)


### show
- 类型：`boolean`
- 默认值：`true`

默认是否显示



### shrink
- 类型：`boolean`
- 默认值：`true`

是否允许折叠



### expand
- 类型：`boolean`
- 默认值：`true`

默认是否展开



### panelSwitchAnimate
- 类型：`boolean`
- 默认值：`true`

面板切换时是否开启动画



### refreshOnPanelActivated
- 类型：`boolean`
- 默认值：`false`

面板切换时是否刷新子组件数据



### panelsShowNum
- 类型：`Array`
- 默认值：`[]`

panel面板右上角显示的数字



### onToggle
- 类型：`(state:boolean)=>void`
- 默认值：`null`

展开或折叠事件



### onBeforePanelSwitch
- 类型：`(panel:object)=>boolean`
- 默认值：`null`

面板切换之前事件，返回false，不允许切换



### panelLazyLoad
- 类型：`boolean`
- 默认值：`false`

面板是否懒加载


## 方法

### show()

显示标签页


### hide()

隐藏标签页


### removePanel(id)
 - 参数：{string} id 面板id

移除指定id的面板


### revertPanel(id)
 - 参数：{string} id 面板id

恢复指定id的面板


### showPanel(id)
 - 参数：{string} id 面板id

显示指定面板


### setPanelBadge(panelId, badge)
 - 参数：{String} panelId 面板ID
 - 参数：{Number} badge 角标数量
 - 返回值：{Tab}

设置面板角标，效果参考[panel](#panels)


### appendItems(panelId, items)
 - 参数：{string} panelId 面板ID
 - 参数：{Array} items 项目数组

向指定面板追加项目


### setPanelTitle(panelId, title)
 - 参数：{string} panelId 面板ID
 - 参数：{string} title 新标题

设置面板标题


### getPanelById(panelId)
 - 参数：{string} panelId 面板ID
 - 返回值：{Object}

根据面板ID获取面板实例


### getPanelByIndex(index)
 - 参数：{number} index 面板索引
 - 返回值：{Object}

根据索引获取面板实例


### refreshItemsByResource(panelId, options)
 - 参数：{string} panelId 面板ID
 - 参数：{object} options 刷新选项
 - 返回值：{Promise}

指定面板加载低代码页面或者低代码页面中的单一组件


### setPanelItems(panelId, options)
 - 参数：{string} panelId 面板ID
 - 参数：{object} options 项目选项
 - 返回值：{Promise}

指定面板加载低代码页面或者低代码页面中的单一组件


### setPanelSrc(panelId, src, pageParam = {})
 - 参数：{string} panelId 面板ID
 - 参数：{string} src 低代码路径
 - 参数：{object} pageParam 页面参数

指定面板动态加载低代码页面


### refreshPanels(panels)
 - 参数：{Array} panels 新的面板配置

刷新面板配置


### syncPanels(panels)
 - 参数：{Array} panels 新的面板配置

增量同步面板配置，支持运行时动态新增或删除 `panel`。当新旧面板使用相同 `id` 时，会尽量保留原有 panel 实例和内部组件状态，不重建已有内容。

建议：
- 动态同步时为每个 panel 设置稳定且唯一的 `id`
- 仅新增、删除或调整标题时优先使用 `syncPanels`


### cleanItems(panelId)
 - 参数：{String} panelId 面板ID

清空面板数据


