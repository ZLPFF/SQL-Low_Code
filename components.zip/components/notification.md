---
sidebarDepth: 1
---

# Notification 消息通知<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#notification-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`''`

组件唯一标识



### rowId

数据id



### title
- 类型：`string`
- 默认值：`''`

组件标题



### message
- 类型：`string`
- 默认值：`''`

消息通知内容



### type
- 类型：`'success'|'danger'|'warning'|'normal'`
- 默认值：`'normal'`

内置声音



### sound
- 类型：`boolean`
- 默认值：`false`

是否有内置声音



### attachmentUrl
- 类型：`string`
- 默认值：`''`

附件路径



### transitionType
- 类型：`string`
- 默认值：`'lower-right'`

弹出框弹出时动画方位



### duration
- 类型：`number`
- 默认值：`0`

弹框自动关闭时间，默认不自动关闭，单位s



### downLoadCategory
- 类型：`'1'|'0'`
- 默认值：`'0'`

下载类型，默认查看，有配置attachmentUrl时才配置'1'



### menuId
- 类型：`string`
- 默认值：`''`

查看时配置的跳转激活菜单id



### confirmText
- 类型：`string`
- 默认值：`''`

查看或者下载按钮显示内容，不配置的话根据下载类型展示



### cancelText
- 类型：`string`
- 默认值：`''`

取消按钮的自定义显示内容，不配置展示取消



### closeAllText
- 类型：`string`
- 默认值：`''`

关闭全部的自定义显示内容



### showCloseAllBtn
- 类型：`boolean`
- 默认值：`false`

显示展示全部按钮



### showHandleBtn
- 类型：`Boolean`
- 默认值：`true`

显示查看、下载按钮



### fileList
- 类型：`array`
- 默认值：`[]`

弹框附件集合



### viewMethod
- 类型：`'no'|'page'|'menu'`
- 默认值：`'no'`

查看展示方式



### pageUrl
- 类型：`string`
- 默认值：`''`

查看时展示弹框的弹框内容路径



### autoCloseRead
- 类型：`boolean`
- 默认值：`false`

自动关闭时，是否已读



### pageActiveForce
- 类型：`boolean`
- 默认值：`false`

点击查看详情时，页面是否关闭再重新打开，当传递的页面参数改变时，可开启此属性



### pageParam
- 类型：`object`
- 默认值：`{}`

点击查看详情时，传递到页面的参数



### onConfirm
- 类型：`Function`
- 默认值：`null`

点击查看或者下载按钮的自定义事件



### onCancel
- 类型：`Function`
- 默认值：`null`

点击取消按钮的自定义事件


