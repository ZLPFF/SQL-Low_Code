---
sidebarDepth: 1
---

# les-page<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#les-page-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### closeAffairPanel
- 类型：`示例：closeAffairPanel:`
- 默认值：`['lesTem']`

不显示事务栏



### affairConfig

事务配置
```javascript
{
    // 是否显示高级配置按钮
    senior: true,
    // 是否显示样式修改按钮
    styleModification: true,
    // 是否显示组件属性按钮
    properties: true,
    // 是否显示导出报告按钮
    exportReport: false,
    // 是否显示录入修改按钮
    inputModify: true,
    // 是否显示组件复核按钮
    componentReview: true,
    // 自定义按钮显示
    customButton: null,
}
```



### drawContainerWidth

绘制的宽度



### baseInfoSeniorConfigExtend

基础信息类型



### printSize
- 类型：`'landscape'|'portrait'|null`

打印不同页面设置方向

 ```javascript
 landscape：横向；
 portrait: 纵向；
 null: 不设置默认纵向，绘制页面宽度自适应
 ```


### saveTemplate

是否保存页面模板



### showAddCordButton

是否显示装订线



### showPrintButton

是否显示打印按钮



### showExportPDFButton

是否导出PDF按钮



### showExportWordButton

是否显示导出word按钮



### showSaveTemplateInInstance

是否显示保存为模板按钮



### lesAutoScroll

激活组件时是否自动滚动



### forceShowAddAnnex

存在特殊业务场景，故添加一个属性可以业务上自己写逻辑显示隐藏按钮



### showAuditTrailButton

顶部工具栏是否显示审计跟踪按钮



### beforeLoginOutSave

超时登陆前自动保存



### diagramDrawCustomTools
- 类型：`object[]`
- 默认值：`[]`

les流程绘制组件自定义节点形状



### annex

LES中附件属性
```javascript
{
    // 弹出框是否模态框 boolean true
    popupIsModal: true,
    // 预览方式，仅支持sunwayoffice和pdf类型文件，modal||blank||iframe string modal
    viewType: 'modal',
}
```



### formatterTreeNodeTitle

左侧树格式化标题



### editAutoSaveTime
- 类型：`单位(s)`

编辑状态自动保存时间



### onBeforeLeafNodeExpandedRender

左侧树渲染前叶子节点展开设置



### onBeforeCompToolbarRender

组件toolbar渲染前配置

 ```javascript
 // 终止自动保存
 onBeforeCompToolbarRender: function(toolbarList) {
     return [...toolbarList,{
                iconType:'circle-swap',
                color:'#056fff',
                text:'自定义按钮',
                onClick: function(){
                         },
            }];
 },
 ```


### onBeforePrint

打印前事件



### onBeforeExport

导出前事件


