---
sidebarDepth: 1
---

# Uploader 上传组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#uploader-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件id，跟随业务命名



### readonly
- 类型：`boolean`
- 默认值：`false`

组件是否只读



### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### multiple
- 类型：`boolean`
- 默认值：`true`

是否能有多个附件，为false时只能上传一个附件



### server
- 类型：`string`
- 默认值：`IFM_CONTEXT+'/core/module/item/files'`

上传文件时的接口



### deleteUrl
- 类型：`string`
- 默认值：`IFM_CONTEXT+'/core/module/item/files'`

删除文件时的接口



### dbTable
- 类型：`string`
- 默认值：`null`

上传时的业务表名称，可以组成targetId的前部分



### bizId
- 类型：`string`
- 默认值：`null`

上传时关联业务表数据的id，可以组成targetId的后部分



### bizCategory
- 类型：`string`
- 默认值：`|`

附件表字段，上传保存和列表查询的业务条件,传数组则支持在上传文件时切换业务类型



### searchUrl
- 类型：`string`
- 默认值：`IFM_CONTEXT+'/core/module/item/files/queries',`

上传查询的接口



### gridSaveService
- 类型：`string`
- 默认值：`'coreFileServiceImpl'`

附件列表中自动保存使用的实现类名称



### accept
- 类型：`string||Array`
- 默认值：`null`

附件允许上传的文件类型(image、audio、pdf、xls、zip、doc、docx、txt)



### gridFilter
- 类型：`boolean`
- 默认值：`false`

快捷查询是否默认展开，等同于列表的filterOpen



### gridPage
- 类型：`boolean`
- 默认值：`true`

是否显示分页，没有分页时，表格会请求所有数据



### autoClose
- 类型：`boolean`
- 默认值：`false`

文件上传完成后自动关闭选择文件弹框



### allowWidth
- 类型：`number`
- 默认值：`0`

允许的最大宽度，由父组件传值



### fill
- 类型：`组件宽高是否填充满父元素`
- 默认值：`boolean`



### fileViewType
- 类型：`string`
- 默认值：`view`

office查看文档模式，只限于sunwayoffice类型文件(view:查看|edit:编辑)



### gridToolbar
- 类型：`Array`
- 默认值：`[]`

显示哪些按钮，编辑和只读页面都生效



### download
- 类型：`boolean`
- 默认值：`true`

是否展示下载按钮属性控制



### preview
- 类型：`boolean`
- 默认值：`true`

//是否展示预览按钮属性控制



### fileOperationLog
- 默认值：`boolean`

是否显示操作记录



### createModal
- 类型：`打开模态框`

点击操作记录,



### gridColumnsFill

//控制列是否充满整个grid(默认true)



### modal

预览文件所传的参数
```javascript
{
    // 预览图片初始化旋转角度
    imageRotate: 0,
    // PDFJS预览pdf时，是否展示打印按钮
    pdfPrint: true,
    // 直接传url预览文件，不需要fileId(新版本组件不用多次请求后台，这个参数意义不大)
    fileUrl: null,
    // 预览pdf时，默认展示的缩放比例
    pdfScale: 'auto',
    // 不能预览的文件类型的提示信息，默认值：‘当前文件类型不支持在线预览，请下载到本地查看。’
    errorMessage: 'upload.tip.preview.error.message',
    // 仅限于pdf文件，是否显示水印
    waterText: '',
```javascript
{
        // 预览时弹框宽度
        width: '80%',
        // 预览时弹框高度
        height: '80%',
        // 预览时弹框是否显示最大化按钮
        showMaxBtn: true,
        // 预览时弹框是否全屏
        isFullScreen: void 0,
}
```



### waterMarkConfig

仅限于sunwayoffice文件，是否显示水印
```javascript
{
        // 水印内容
        text: '',
        // 水印尺寸
        size: '',
        // 水印颜色
        color: '',
        // 水印布局
        layout: '',
}
```



### download

下载按钮



### print

打印按钮



### viewType

预览方式(这里优先级最高，options里面的低)：modal/blank/iframe



### officeTmplId

编辑时，Word/Excel/ELN报告模板文件id



### eln

编辑模板是否eln模板



### service

eln模板service默认值：coreOfficeELNInvokeConsumer，其他文件：coreOfficeTemplateInvokeConsumer



### comment

传入false禁止批注功能



### printLimitNum

打印次数限制



### printCount

已经打印的次数



### workflow
- 类型：`值是数组,`
- 默认值：`如果不传值,`

工作流程对应的文本控制标签,



### trackChanges

true修订模式默认开启



### trackChangesOperation

false不显示修订模式的修改记录的确认和取消（对勾和叉）



### fillForms
- 类型：`且不可删除文本控制区域`

只能修改文本控制区域的内容，



### pageOfficeParam

pageOffice预览时需要的额外参数



### popupIsModal
- 类型：`boolean`
- 默认值：`true`

弹出框是否模态框



### viewType
- 类型：`string`
- 默认值：`modal`

预览方式，仅支持sunwayoffice类型文件，modal||blank||iframe



### immediateUpload
- 类型：`boolean`
- 默认值：`false`

是否直接上传(false为不直接上传)



### batchDownload
- 类型：`boolean`
- 默认值：`false`

批量下载按钮显示



### batchDownloadId
- 类型：`string`
- 默认值：`'core-uploader-batch-download-id'`

批量下载按钮的id



### batchPreview
- 类型：`boolean`
- 默认值：`false`

批量预览按钮显示



### batchPreviewId
- 类型：`string`
- 默认值：`'core-uploader-batch-preview-id',`

批量预览按钮的id



### gridGeneralButtonGroup
- 类型：`boolean`
- 默认值：`false`

是否显示列表按钮组工具



### scope
- 类型：`string`
- 默认值：`null`

上传时传入附件表的字段值



### gridOptions
- 类型：`object`
- 默认值：`{}`

grid列表属性



### webkitdirectory
- 类型：`boolean`
- 默认值：`false`

是否支持上传文件夹



### allowCustomUpload
- 类型：`boolean`
- 默认值：`false`

是否允许自定义上传，开启后只会执行beforeFilesUpload,可以在该钩子获取uploadFiles，定制上传操作



### uploadModalTitle
- 类型：`string`
- 默认值：`文件上传`

上传文件弹出框标题



### uploadSuccessMessage
- 类型：`string`
- 默认值：`上传成功`

文件上传成功的提示信息



### toolbarAlign
- 类型：`'right'|'left'`
- 默认值：`'right'`

工具栏中按钮的对齐方式



### requestHeader
- 类型：`object`
- 默认值：`{}`

请求头



### listType
- 类型：`'directory'|'file'`
- 默认值：`'file'`

列表展示方式为目录或文件，目录模式下，只能上传文件夹



### formatterGridToolbar
- 类型：`Function(toolbar)`

定制Grid上方工具栏



### formatterGridColumns
- 类型：`Function(columns)`

定制Grid中的列，参数为当前列字段



### beforeDownloadRender
- 类型：`Function`

是否展示下载按钮



### beforePreviewRender
- 类型：`Function`

是否展示预览按钮



### onBeforeUpload

上传之前做的操作，如果返回false或者bizId为null就不上传



### onBeforeRefresh

刷新之前做的操作，参数为列表的requestData，返回false则不刷新



### onGridRowActive

附件列表激活行操作



### onGridLoadSuccess

附件列表加载成功操作



### onClickPreview

点击预览按钮所做的操作，定义了此方法就不会走产品的预览方案



### onCellDbClick

列表双击事件



### onBeforeDownLoad

下载附件之前的操作



### displayInfo

展示信息


## 方法

### setReadonly(readonly = true)
 - 返回值：Boolean

设置只读时按钮显隐问题处理


### setOptions(param)
 - 参数：{Object} param 查询条件

设置查询条件


### setUploadData(data)
 - 参数：{Object} param 上传数据

设置上传数据


### closeModal()
 - 返回值：Uploader

关闭上传弹框


### setToolbarVisible(state = true)
 - 返回值：Uploader

切换顶部按钮显示状态


### refresh()
 - 返回值：Uploader

刷新


### getData()
 - 返回值：Uploader

获取列表数据


### cleanData()

清空数据


