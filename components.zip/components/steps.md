---
sidebarDepth: 1
---

# Steps 步骤条<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#steps-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件id



### url
- 类型：`string`
- 默认值：`null`

接口请求地址



### requestData
- 类型：`object`
- 默认值：`null`

接口筛选条件



### items
- 类型：`object[]`
- 默认值：`[]`

若没配置url，可指定数据源

 ```javascript
 {
     items: [
         {
             text: '节点一',
             value: 'one',
             status: 'process',
         },
         {
             text: '节点二',
             value: 'two',
             status: 'next',
        },
         {
             text: '节点三',
             value: 'three',
             status: 'wait',
         },
         {
             text: '节点四',
             value: 'four',
             status: 'finish',
         },
     ],
 },
 ```
 效果如下：
 ![items属性](/docs/steps-items.png)


### onItemClick
- 类型：`(item)=>void`
- 默认值：`null`

每项的点击事件


## 方法

### refreshItems(items = [])
 - 参数：{object[]} [items=[]]

刷新列表，items参数参考[items](#items)配置


