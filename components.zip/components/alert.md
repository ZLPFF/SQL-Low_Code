---
sidebarDepth: 1
---

# alert<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#alert-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### type
- 类型：`'success'|'info'|'warning'|'error'`
- 默认值：`'warning'`

警告提示的样式



### title
- 类型：`string`
- 默认值：`提示`

标题



### message
- 类型：`string`
- 默认值：`null`

提示内容



### onConfirm
- 类型：`()=>void`
- 默认值：`null`

点击确认按钮触发


## 方法

