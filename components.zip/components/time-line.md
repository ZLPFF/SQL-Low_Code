---
sidebarDepth: 1
---

# TimeLine 时间线组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#time-line-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`''`

组件id



### renderTo
- 类型：`dom`
- 默认值：`null`

渲染位置



### rendered
- 类型：`function`
- 默认值：`null`

渲染完成事件


## 方法

### setData(data)
 - 参数：data undefined

设置数据


### getData()

获取数据


