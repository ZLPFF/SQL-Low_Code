---
sidebarDepth: 1
---

# ImageViewer 图片预览<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#imageViewer-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件ID



### src
- 类型：`string[]`
- 默认值：`[]`

图片路径

 ```javascript
 {
     src: [IFM_CONTEXT+"static/img/test1.png", IFM_CONTEXT+"static/img/test1.png"]
 }
 ```
 效果展示：
 ![imageViewer](/docs/imageViewer.png)


### initialViewIndex
- 类型：`number`
- 默认值：`0`

初始化时默认展示第几张图片



### enableOrientation
- 类型：`boolean`
- 默认值：`false`

是否启用拍摄方向,图片中exif信息中的orientation属性，记录了拍摄方向。设置为true,则图片会进行相应的旋转来展示


## 方法

### refresh(pathList)
 - 参数：{string[]} pathList

刷新图片
 ```javascript
 var pathList = [ IFM_CONTEXT + "/static/img/test1.png", IFM_CONTEXT + "/static/img/test1.png"];
 Gikam.getComp("ID").refresh(pathList);
 ```


