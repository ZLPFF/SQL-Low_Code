---
sidebarDepth: 1
---

# Home 登录页<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#home-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### logo

logo图片地址



### I18NUrl

国际化文件



### skin

皮肤主题，选择范围green/blue



### style

皮肤风格



### selectDeptAndRole

是否选择部门和角色



### xIconUrl

配置系统小图标



### system

系统名称



### userRemember

是否记住登录用户名



### locale

默认语言



### i18n

是否显示中英文切换



### nativePassword

是否使用浏览器记住密码



### retrievePassword

是否找回密码



### philosophy

宣传标语，如企业slogan



### lottieWebUrl

动画lottie文件地址



### defaultFocusStatus

是否默认聚焦用户名输入框



### qrCode

二维码登录



### smsLogin

是否短信登录



### dingTalkSmsLogin

是否钉钉登录



### loginTenant

是否租户登录



### customContent
- 类型：`string`
- 默认值：`null`

在登录面板中自定义内容

 ```javascript
 // 如下增加注册按钮
 customContent: '<a href="javascript:;" onclick="register()">注册</a>'
 ```


### deptRoleSearch

部门和角色下拉框是否开启搜索框



### loginSuccessUrl

登陆成功之后的跳转路径



### grayMode

灰色模式



### homeLoadSuccess

登录页加载完事件



### onEncryptPassword
- 类型：`(password,rsaPublicKey)=>password`
- 默认值：`null`

登录请求发送之前,加密密码时触发,可业务上返回其他算法加密后的密码



### onBeforeRender

页面渲染前事件



### onBeforeLogin

登录请求发送前事件



### onRetrievePasswordClick

找回密码点击



### onHandleLoginPreparation

登录面板中设置了自定义内容后，点击登录按钮的预处理逻辑事件


## 方法

