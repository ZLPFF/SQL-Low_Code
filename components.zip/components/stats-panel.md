---
sidebarDepth: 1
---

# StatsPanel 统计面板组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#stats-panel-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`渲染位置`
- 默认值：`dom`



### columns
- 类型：`列宽180px`

列数，



### title

标题



### subtitle

子标题



### items

数据列表

items: [{
    title:'数据标题',
    countColor:'blue',
    count:3,
    subtitle:{
         textColor : 'green',
        text : '小标题',
        sideColor : 'red',
         sideText : 'ssss'
     }
 }],

