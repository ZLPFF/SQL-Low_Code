---
sidebarDepth: 1
---

# Video 视频组件<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#video-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`''`

组件id



### muted
- 类型：`boolean值`

是否默认静音



### playbackRates

播放速度



### height

视频高度



### width

视频宽度



### preload
- 类型：`boolean值`

是否预加载



### autoplay
- 类型：`boolean值`

是否自动播放



### poster

视频封面图片



### disableForward
- 类型：`true表示禁止`
- 默认值：`false表示不禁止`

是否禁用快进，boolean值



### sources

视频源



### renderTo
- 类型：`dom`
- 默认值：`null`

渲染位置


