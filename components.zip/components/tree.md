---
sidebarDepth: 1
---

# Tree 树<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#tree-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### height
- 类型：`number||string`
- 默认值：`'100%'`

组件高度



### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### name
- 类型：`string`
- 默认值：`null`

名称



### url
- 类型：`string`
- 默认值：`null`

数据请求地址



### requestData
- 类型：`object`
- 默认值：`null`

接口请求时的过滤条件



### selectedNodeData
- 类型：`object`
- 默认值：`null`

激活的节点数据



### cascadeCheck
- 类型：`boolean`
- 默认值：`true`

勾选节点时，父节点和子节点是否同步勾选



### data
- 类型：`object[]`
- 默认值：`[]`

若没有配置url，可配置默认加载的数据



### baseUrl
- 类型：`string`
- 默认值：`null`

对应后台Resource中的接口地址，在新增删除节点时使用



### nodeTextField
- 类型：`string`
- 默认值：`'text'`

节点名称对应的字段



### edit
- 类型：`boolean`
- 默认值：`false`

点击节点时，是否允许编辑



### customEditButtons
- 类型：`object[]`
- 默认值：`[]`

自定义按钮，当edit为true时生效



### async
- 类型：`boolean`
- 默认值：`true`

子节点加载是否是异步，若异步，展开当前节点时，才加载子节点



### checkbox
- 类型：`boolean`
- 默认值：`false`

节点是否显示复选框



### checkOnActive
- 类型：`boolean`
- 默认值：`true`

点击节点时，是否级联勾选复选框



### draggable
- 类型：`boolean`
- 默认值：`false`

节点是否可以拖拽改变层级



### expandOnTextClick
- 类型：`boolean`
- 默认值：`true`

点击名称时是否允许展开收缩当前节点



### nodeStyleFormatter
- 类型：`(node)=>object`
- 默认值：`null`

节点样式格式化方法

 ```javascript
 nodeStyleFormatter(node) {
     if (node.name === '节点一') {
         return {
             backgroundColor: 'red',
             textDecoration: 'line-through';
         }
     }
 }
 ```


### forceCascadeDelete
- 类型：`boolean`
- 默认值：`false`

节点可编辑时，删除节点，是否忽略是否有子节点存在的校验。false时，若存在子节点，则不允许删除



### search
- 类型：`boolean`
- 默认值：`false`

当async为false时，是否开启节点名称搜索功能



### onNodeToggle
- 类型：`(node)=>void`
- 默认值：`null`

节点展开和收缩节点事件



### onNodeChecked
- 类型：`(node)=>void`
- 默认值：`null`

节点复选框勾选事件



### onNodeSelected
- 类型：`(node)=>void`
- 默认值：`null`

节点激活事件



### onBeforeRequest
- 类型：`()=>boolean`
- 默认值：`null`

接口请求前，返回false，则不请求



### onBeforeDelete
- 类型：`()=>boolean`
- 默认值：`null`

节点删除前，返回false，则删除



### onAfterDrop
- 类型：`()=>void`
- 默认值：`null`

节点拖放结束



### onLoadSuccess
- 类型：`(data)=>void`
- 默认值：`null`

数据加载成功



### onBeforeSave
- 类型：`()=>void`
- 默认值：`null`

节点保存之前



### onAfterDelete
- 类型：`(node)=>void`
- 默认值：`null`

节点删除之后



### onNodeDblclick
- 类型：`(node)=>void`
- 默认值：`null`

双击事件


## 方法

### selectNodeById(id)
 - 参数：{string|number} id

通过id激活指定节点


### refreshNode(nodeId)
 - 参数：{String,Number} nodeId 要刷新的节点id
 - 返回值：Tree

刷新指定节点，如果nodeId为空，则刷新整棵树


### setNodeText(nodeId, text)
 - 参数：{string|number} nodeId 节点id
 - 参数：{string} text 节点名称
 - 返回值：undefined

设置节点名称，只用于前端显示，不会更新实际数据


### getTreeList()
 - 参数：undefined undefined

获取树节点数据


### setNodeExpand(nodeId, expand = true)
 - 参数：{string} nodeId 树节点id，可以不写默认处理全部节点数据
 - 参数：{boolean} expand 是否展开，默认为true

展开或折叠指定节点


### nodeExistsById(nodeId)
 - 参数：{string} nodeId 需判断的节点id

通过id判断节点是否存在


### activeNodeById(nodeId)
 - 参数：{string|number} nodeId

激活节点，不触发节点展开收缩动作


### checkNodeById(nodeId)
 - 参数：{string|number} nodeId

勾选节点


### unCheckNodeById(nodeId)
 - 参数：{string|number} nodeId

取消勾选节点


### setNodeStyle(nodeId, customStyle)
 - 参数：{string} nodeId 节点id
 - 参数：{object} customStyle 自定义的css样式，示例{color:'red'}

设置节点样式


