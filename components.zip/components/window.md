---
sidebarDepth: 1
---

# Window 窗口<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#window-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### title
- 类型：`string`
- 默认值：`null`

一级标题



### showTitle
- 类型：`boolean`
- 默认值：`true`

是否显示标题



### toolbarAlign
- 类型：`'left'|'center'|'right'`
- 默认值：`'right'`

按钮对齐方式



### toolbarTop
- 类型：`boolean`
- 默认值：`true`

按钮工具栏是否显示在顶部



### dataLock
- 类型：`boolean`
- 默认值：`false`

是否开启页面锁功能



### loadingMode
- 类型：`'normal'|'retro'|'progress'`
- 默认值：`'progress'`

页面加载中过渡效果



### alwaysButton
- 类型：`Array`
- 默认值：`[]`

页面一直显示的按钮，支持按钮的icon或者按钮id



### cleanUnSavedOnGoBack
- 类型：`boolean`
- 默认值：`false`

goBack时是否清空未保存标识


## 方法

### showMask()

打开窗口遮罩


### closeMask()

关闭窗口遮罩


### load(url, remember = true, param = {}, pageConfig)
 - 参数：{string} url -
 - 参数：{boolean} remember -
 - 参数：{Object} param -
 - 参数：{Object} pageConfig -

加载页面，会追加到历史路由中，使用goBack方法会跳转到前一页面


### replace(url, pageParams = {}, pageConfig)
 - 参数：{string} url -
 - 参数：{boolean} remember -
 - 参数：{Object} pageParams -
 - 参数：{Object} pageConfig -

加载页面，不会追加到历史路由中，使用goBack方法会跳转到前两页


### reload()

重新加载当前页面


### enterFullScreen()

进入全屏模式


### exitFullScreen()

进入全屏模式


### goBack()
 - 参数：{object} [options={validate,refresh}]
 - 返回值：Deferred

返回前一路由页面


### removeTitle()
 - 返回值：undefined

移除标题区域


### save(param)
 - 参数：{object} param
 - 返回值：Deferred

保存页面数据


### setAlwaysButton(buttons)
 - 参数：Array [buttonId]

设置窗口中哪些按钮会一直显示


### loadPage(resourcePath, pageParam = {})
 - 参数：{string} resourcePath
 - 参数：{JsonWrapper} param

加载开发平台页面


### getPageParam()
 - 参数：{string} resourcePath
 - 参数：{JsonWrapper} param

获取开发平台页面参数


### refreshToolbar(options)
 - 参数：{string} resourcePath
 - 参数：{JsonWrapper} param

刷新工具栏


### getMainPageUrl()
 - 返回值：{string}

获取页面不带上下文的地址


### getComp(id)
 - 参数：{string} id -
 - 返回值：{Object}

根据组件ID获取对应的组件实例


### isDataModified()

验证组件数据是否发生变更


### setTitle(title)
 - 参数：{string} title -

设置窗口标题


### enableLock()

启用窗口锁定模式


### disableLock()

禁用窗口锁定模式


### getResourceId()
 - 返回值：{String|Number}

获取低代码页面ID


### onLoad(callback)
 - 参数：{Function} callback -

添加页面加载时要执行的回调函数


### saveSuccess()

调用自定义的接口保存数据后，保存按钮状态修改*（去掉小红点状态）


### isPageLoading()

页面是否加载中


### getSaveButton()

获取保存按钮


