---
sidebarDepth: 1
---

# Echarts 图表<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#echarts-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### option
- 类型：`object`
- 默认值：`null`

图表参数,其值为Echarts图表option配置



### config
- 类型：`object`
- 默认值：`{dropDownMenu:[],search:{}}`

配置顶部下拉菜单和查询条件
```javascript
{
    dropDownMenu: [],
    search: {},
}
```


## 方法

### setOption(options, refreshFlag)
 - 参数：{object} options

同Echarts的setOptions方法相同


### setSize(size)
 - 参数：{object} size {width:100,height:100}

自定义echarts宽高


### setConfig(config)
 - 参数：{ Object }

修改工具栏下拉菜单和查询条件


## 应用

### 折线图配置示例

```javascript
const config = {
    // 同echarts配置参数相同
    option: {
          xAxis: {
            type: 'category',
            data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
          },
          yAxis: {
            type: 'value'
          },
          series: [
            {
              data: [150, 230, 224, 218, 135, 147, 260],
              type: 'line'
            }
          ]
    },
    config: {
        dropDownMenu: [
            {
                type: 'button',
                text: '按钮一',
                onClick: function() {
                    alert('按钮一');
                },
            },
            {
                type: 'button',
                text: '按钮一',
                onClick: function() {
                    alert('按钮一');
                },
            },
        ],
        search: {
            type: 'form',
            fields: [
                {
                    field: 'field',
                    title: '查询条件一',
                },
            ],
        },
    },
};
```
![Echarts图表](/docs/echarts.png)
::: tip 提示
option为Echarts中的配置参数
:::
