---
sidebarDepth: 1
---

# SampleLocation 样品储存<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#sampleLocation-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### id
- 类型：`string`
- 默认值：`null`

组件id，跟随业务命名



### data
- 类型：`Array`
- 默认值：`[]`

样品位置的内容

 ```javascript
 data : [{
    // 样品存储位置的行数，数据第一条如果含有rowNum，则SampleLocation配置的rowNum被覆盖
    rowNum : 2,
    // 样品存储位置的列数，数据第一条如果含有colNum，则SampleLocation配置的colNum被覆盖
    colNum : 3,
    // 此数据所在的行位置
    x : 1,
    // 此数据所在的列位置
    y : 1
    id : '数据id',
    // 系统内置三种类型样式：blood、cell、dna，其中cell是带有干细胞背景图
    // 也可以配置bgIcon中的属性类型，自定义配置图片路径
    sampleType : 'blood || cell || dna',
    // 配置bgColor中的属性类型，自定义配置背景颜色
    stockType : 'out || in',
    text : '显示内容',
    title :'鼠标悬浮提示信息'
 }]

 ```


### url
- 类型：`string`
- 默认值：`null`

请求数据的接口地址



### rowNum
- 类型：`number`
- 默认值：`0`

样品存储位置的行数



### colNum
- 类型：`number`
- 默认值：`0`

样品存储位置的列数



### xSerialType
- 类型：`string`
- 默认值：`'number'`

行排列是数字还是字母，number||letter



### ySerialType
- 类型：`string`
- 默认值：`'letter'`

列排列是数字还是字母，number||letter



### ySerialPosition
- 类型：`left||right`

列排列坐标在左侧还是右侧



### xSerialSort
- 类型：`LTR`
- 默认值：`从左到右`

行排列坐标



### cellSize

//单元格大小(px)



### width
- 类型：`number`

组件宽度



### height
- 类型：`number`

组件高度



### bgIcon

数据data中sampleType的配置映射，可配置映射图片

 ```javascript
 bgIcon : {
    blood: '/static/gikam/lims/home/img/blood.svg',
    cell: '/static/gikam/lims/home/img/stem-cells.svg',
    dna: '/static/gikam/lims/home/img/dna.svg',
    customer: '/static/gikam/lims/home/img/customer.svg'
 }
 ```


### bgColor

数据data中stockType的配置映射，可配置映射图片

 ```javascript
 bgIcon : {
    out: 'green',
    in: 'blue',
 }
 ```


### bgCanvasShow
- 类型：`true`

背景圆圈是否显示，boolean



### onClick

单机选中事件，参数data



### onDblClick

自定义双击事件，如果不配置，双击样品则和右键效果一致



### onLoadSuccess

调用接口请求数据完成之后的操作，参数rows



### contextMenu

//如果写了onDblClick双击事件，则双击不会出现弹出列表

 ```javascript
 contextMenu: [{
     text: '整行移动至',
     onClick: function (data) {
         this.moveRow();
     }
 },
 {
     text: '整列移动至',
     onClick: function (data) {
         this.moveCol();
     }
 }]
 ```


### contextMenuParam
- 类型：`object`
- 默认值：`{width:`

右键弹框的属性，目前只支持配置width



### onBeforeContextMenu

右键样品弹出选择菜单之前的事件，可返回菜单内容，动态修改右键后弹出的菜单内容，参数为样品数据data

 ```javascript
 onBeforeContextMenu: function(data){
   if (data.x === 1) {
      return [{
          text: '清空所选板格',
      }]
   }
   return [
      {
           text: '整行移动至',
           onClick: function (data) {
               this.moveRow();
           }
       },
       {
           text: '整列移动至',
           onClick: function (data) {
               this.moveCol();
           }
       }]
 }
 ```

## 方法

### setData(data)
 - 参数：{ Array }

动态设置数据


### addSample(data)
 - 参数：{ Object }

添加到某个位置


### setSerialType(option)
 - 参数：{ Object }

动态改变坐标显示内容(数字或字母显示)


### sampleSelect(id, type)
 - 参数：{ String }
 - 参数：{ Boolean }

选中方法


### activateItemById(id)
 - 参数：{ String }

通过id激活事件


### getActivatedItem()
 - 返回值：{object}

获取激活样品的信息


### getActivatedItems()
 - 返回值：{object[]}

获取激活全部信息


### cleanSampleById(id)
 - 参数：{ String }

通过id设置空白，背景色和背景图片会被清空


### cleanSelectedSamples()

所有样品置为空白，背景色和背景图片会被清空


### moveRow()

移动整行


### moveCol()

移动整列


### exportPdf(fileName)
 - 参数：{ String }

导出pdf，文件名称，不传默认userName+时间戳


### exportPng(fileName)
 - 参数：{ String }

导出图片，件名称，不传默认时间戳


### moveSingle()

移动单个样品


## 应用

### 样品存储位置演示:

![SampleLocation](/docs/SampleLocation.gif)
