---
sidebarDepth: 1
---

# Gantt 甘特图<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#gantt-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### zoomConfig
- 类型：`object`
- 默认值：`null`

天，周，月，年等时间缩放，由于核心默认展示月份，设置此属性时必须带着月份，需要和showForm一起使用

 ```javascript
 {
     zoomConfig: {
         levels: [ {
                 name: 'day',
                 label: '天',
                 scale_height: 27,
                 min_column_width: 80,
                 scales: [
                     { unit: 'day', step: 1, format: '%d %M' }
                ]
             }, {
                 name: 'week',
                 label: '周',
                 scale_height: 50,
                 min_column_width: 50,
                 scales: [{
                         unit: 'week', step: 1, format: function (date) {
                             var dateToStr = this.$gantt.date.date_to_str('%d %M');
                             var endDate = this.$gantt.date.add(date, -6, 'day');
                             var weekNum = this.$gantt.date.date_to_str('%W')(date);
                             return '#' + weekNum + ', ' + dateToStr(date) + ' - ' + dateToStr(endDate);
                         }
                     },
                     { unit: 'day', step: 1, format: '%j %D' }
                 ]
             }, {
                 name: 'month',
                 label: '月',
                 scale_height: 50,
                 min_column_width: 120,
                 scales: [
                     { unit: 'month', format: '%F, %Y' },
                     { unit: 'week', format: 'Week #%W' }
                 ]
             }, {
                 name: 'year',
                 label: '年',
                 scale_height: 50,
                 min_column_width: 120,
                 scales: [
                     { unit: 'year', format: 'Year #%Y' },
                     { unit: 'month', format: '%F, %Y' }
                 ]
              } ]
         }
 }
 ```


### showForm
- 类型：`是否显示表单，必须和zoomConfig一起使用`
- 默认值：`boolean`

时间轴切换



### draggable
- 类型：`boolean`
- 默认值：`false`

是否允许拖拽



### controlButton
- 类型：`boolean`
- 默认值：`false`

是否展示页面控制按钮，包含：自适应屏幕、导出PNG



### weekend
- 类型：`boolean`
- 默认值：`false`

展示工作日



### skin
- 类型：`String`
- 默认值：`terrace`

皮肤默认terrace，可选：broadway||contrast_black||contrast_white||material||meadow||skyblue||terrace

 皮肤-broadway
 ![broadway](/docs/gantt-broadway.png)
 皮肤-contrast_black
 ![contrast_black](/docs/gantt-contrast_black.png)
 皮肤-contrast_white
 ![contrast_white](/docs/gantt-contrast_white.png)
 皮肤-material
 ![material](/docs/gantt-material.png)
 皮肤-meadow
 ![meadow](/docs/gantt-meadow.png)
 皮肤-skyblue
 ![skyblue](/docs/gantt-skyblue.png)
 皮肤-terrace
 ![terrace](/docs/gantt-terrace.png)

