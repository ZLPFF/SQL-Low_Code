---
sidebarDepth: 1
---

# EchartsSpc SPC图表<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#echarts-spc-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### data
- 类型：`[]`
- 默认值：`[]`

数据



### columns
- 类型：`string[]`
- 默认值：`[]`

表格显示的列

 ```javascript
 [
     {
        field : 'id',
        title : 'T_CORE_USER.ID',
        type : 'link',
        genericQuery : true,
        width: 100
     }, {
        field : 'userNo',
        title : 'T_CORE_USER.USERNO',
        genericQuery : true,
        width: 150,
        calculated:true,         // 需要计算数据的字段
     },
 ]
 ```


### spcType
- 类型：`spcSingle|spcRange|spcMeanRange|spcMeanByRange|spcMeanByStandard|spcStandard|spcDefect|spcUnqualified`
- 默认值：`spcSingle`

图表类型

 ```javascript
 [
     spcSingle: 单值图
     spcRange: 单值极差控制图(X-R)
     spcMeanRange: 均值极差控制图(Xbar-R)
     spcMeanByRange: '均值极差-均值图
     spcMeanByStandard: 均值标准差-均值图
     spcStandard: 标准差图
     spcDefect: 缺陷数控制图(C图)
     spcUnqualified: 不合格品数控制图(NP图)
 ]
 ```


### customMenu
- 类型：`[]`
- 默认值：`[]`

//自定义菜单



### linkComponentIds
- 类型：`[]`
- 默认值：`[]`

关联图表id



### legend
- 类型：`boolean`
- 默认值：`true`

是否显示头部导航



### rules
- 类型：`[]`
- 默认值：`[]`

默认规则



### spcTypeItems
- 类型：`[]`
- 默认值：`[]`

自定义类型下拉框



### line
- 类型：`object`
- 默认值：`{}`

默认水平线数值
```javascript
{
    UCL: null,
    LCL: null,
    USL: null,
    LSL: null,
}
```



### singeTooltipFields
- 类型：`[]`
- 默认值：`[]`

单值图悬浮框显示配置



### yStartValue
- 类型：`string`
- 默认值：`null`

y轴坐标开始值



### yEndValue
- 类型：`string`
- 默认值：`null`

y轴坐标结束值



### xStartValue
- 类型：`number`
- 默认值：`0`

x轴坐标开始值



### xEndValue
- 类型：`number`
- 默认值：`10`

y轴坐标结束值



### showGraphicalConfigurationMenu
- 类型：`boolean`
- 默认值：`true`

显示图形配置菜单



### showAdditionalHorizontalLinesMenu
- 类型：`boolean`
- 默认值：`false`

显示添加水平线菜单



### showDetailMenu
- 类型：`boolean`
- 默认值：`true`

显示详情菜单



### showAbstractMenu
- 类型：`boolean`
- 默认值：`true`

显示摘要菜单



### showSaveImageMenu
- 类型：`boolean`
- 默认值：`true`

显示保存图片菜单



### title
- 类型：`string`
- 默认值：`null`

图表标题



### displayedLines
- 类型：`'LCL',`
- 默认值：`'UCL',`

默认显示的水平线,为空则默认为['AVG',



### yMinValue
- 类型：`number`
- 默认值：`null`

y轴最小值



### yMaxValue
- 类型：`number`
- 默认值：`null`

y轴最大值



### showMarkArea
- 类型：`boolean`
- 默认值：`true`

是否显示区域背景色



### ySplitNumber
- 类型：`number`
- 默认值：`5`

y轴的分割段数



### percentPrecision
- 类型：`number`
- 默认值：`null`

小数精度



### customChartName
- 类型：`string`
- 默认值：`null`

自定义图形名称



### onLoadSuccess
- 类型：`function`
- 默认值：`null`

数据加载完成事件


## 方法

### setData(data, condition)
 - 参数：{Object} data
 - 参数：{Object} condition

设置数据


### setParams(options, conditions, data)
 - 参数：{Object} options
 - 参数：{Object} condition
 - 参数：{Object} data

设置条件


### getParams()

获取条件


### setUnCheckedRules(unCheckedRules)
 - 参数：{Array} unCheckedRules -

设置未选中的规则


### getSpcData(operate)
 - 参数：{String} operate 操作类型，可选值：'get'、'set'、'add'、'remove'

获取Spc数据


### cleanData(initDisplayedLines = true)
 - 参数：{boolean} initDisplayedLines -

清理数据函数


### setTitle(title)
 - 参数：{string} title

设置标题


### setDisplayedLines(displayedLines)
 - 参数：{string[]} displayedLines

设置显示的水平线


### setXAxisRange(xStartValue, xEndValue)
 - 参数：{number} xStartValue
 - 参数：{number} xEndValue

设置x轴的显示范围


### setYAxisRange(yStartValue, yEndValue)
 - 参数：{number} yStartValue Y轴的起始数值
 - 参数：{number} yEndValue Y轴的结束数值

设置Y轴的数值范围


### setYAxisInterval(yMinValue, yMaxValue)
 - 参数：{number} yMinValue -
 - 参数：{number} yMaxValue -

设置Y轴刻度间隔


### setAdditionalHorizontalLines(additionalHorizontalLines = [])
 - 参数：{[]} additionalHorizontalLines水平线数组

设置新增水平线


### setShowMarkArea(show = true)
 - 参数：{boolean} show 默认值true

设置是否显示区域背景色


### setYSplitNumber(ySplitNumber)
 - 参数：{boolean} show 默认值true

设置Y轴分割数


### setCustomChartName(customChartName)
 - 参数：{string} customChartName -

设置自定义图表名称


### setPercentPrecision(percentPrecision)
 - 参数：{number} percentPrecision 百分比精度

设置百分比精度


