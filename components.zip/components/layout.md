---
sidebarDepth: 1
---

# Layout 布局<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#layout-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### renderTo
- 类型：`HTMLElement`
- 默认值：`null`

渲染到的DOM元素



### id
- 类型：`string`
- 默认值：`null`

组件ID



### north
- 类型：`object`
- 默认值：`{}`

北区域参数



### south
- 类型：`object`
- 默认值：`{}`

南区域参数



### west
- 类型：`object`
- 默认值：`{}`

西区域参数



### east
- 类型：`object`
- 默认值：`{}`

东区域参数



### center
- 类型：`object`
- 默认值：`{}`

中区域参数



### onRendered
- 类型：`()=>void`
- 默认值：`null`

组件加载成功的事件处理函数，当组件渲染完成时调用


## 方法

### setSize(props)
 - 参数：{object} props 各区域宽、高参数，例如{east:{width:200}}}

动态设置layout各区域尺寸


### setAreaSrc(direction, src, pageParam = {})
 - 参数：{string} direction -
 - 参数：{string} src -
 - 参数：{object} [pageParam={}] -

在指定区域加载低代码页面


### getPosition(direction)
 - 参数：{string} direction -
 - 返回值：{object|null}

获取指定方向的区域对象


