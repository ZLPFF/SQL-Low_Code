---
sidebarDepth: 1
---

# TrainingVideoGrid 视频列表<a title="试一试" class="try-link" href="http://172.16.172.74/docs-try#training-video-grid-try" target="_blank"><img src="/docs/code-try.png"/></a>

## 属性 


### width
- 类型：`number`
- 默认值：`360`

每个视频宽度



### height
- 类型：`number`
- 默认值：`90`

每个视频高度



### onlyPlayer
- 类型：`boolean`
- 默认值：`true`

是否只能播放一个视频



### requestData
- 类型：`object`
- 默认值：`{}`

获取数据时的接口参数



### videoData
- 类型：`array`
- 默认值：`[]`

展示列表的数据

 ```javascript
 data: [{
    videoPoster: '未播放时展示的图片',
    videoType: 'video/mp4',
    src: '视频地址',
    title: '标题',
    videoDuration: 时长,
    videoPresenter: '演讲人',
 }]
 ```


### url
- 类型：`string`
- 默认值：`''`

获取数据时的接口



### renderTo
- 类型：`dom`
- 默认值：`null`

渲染位置


